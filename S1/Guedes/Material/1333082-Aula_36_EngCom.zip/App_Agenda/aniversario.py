class Aniversario:
    def __init__(self, dia=1, mes=1):
        if e_valida(dia, mes):
            self.__dia = dia
            self.__mes = mes
        else:
            self.__dia = 1
            self.__mes = 1

    def get_dia(self):
        return self.__dia

    def get_mes(self):
        return self.__mes

    def set_dia(self, n_dia):
        self.set_aniv(n_dia, self.__mes)

    def set_mes(self, n_mes):
        self.set_aniv(self.__dia, n_mes)

    def set_aniv(self, novo_dia, novo_mes):
        if e_valida(novo_dia, novo_mes):
            self.__dia = novo_dia
            self.__mes = novo_mes

    def __str__(self):
        return "{:02d}/{:02d}".format(self.__dia, self.__mes)

    def __lt__(self, outro):
        return (self.__mes, self.__dia) < (outro.__mes, outro.__dia)

def e_valida(dia, mes):
    ndm = (0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
    if mes < 1 or mes > 12 or dia < 1 or dia > ndm[mes]:
        return False
    return True
    

import tkinter as tk
import hora
from datetime import datetime

jan = tk.Tk()
agora = datetime.now()

rbu_var = tk.IntVar()
rbu_var.set(1)

h = hora.Hora(agora.hour, agora.minute, agora.second)

mon_var = tk.StringVar()
mon_var.set(h.str_12())
mon = tk.Entry(jan, bg="black", fg="lime", textvariable=mon_var)
mon.configure(font=("Arial", "60"), width=11, justify=tk.CENTER)
mon.grid(column=0, row=0, columnspan=3)

def tick():
    h.mais_um_segundo()
    if rbu_var.get() == 1:
        mon_var.set(h.str_12())
    else:
        mon_var.set(h)
    mon.after(1000, tick)
mon.after(1000, tick)


tk.Label(jan, text="Formato de:", font=("Arial", "12", "bold")).grid(column=0, row=1)

rbu12 = tk.Radiobutton(jan, text="12 horas", value=1, variable=rbu_var)
rbu12.configure(font=("Arial", "12", "bold"))
rbu12.grid(column=1, row=1)

rbu24 = tk.Radiobutton(jan, text="24 horas", value=2, variable=rbu_var)
rbu24.configure(font=("Arial", "12", "bold"))
rbu24.grid(column=2, row=1)

jan.resizable(0,0)
jan.title("Relógio - IFCE")






jan.mainloop()

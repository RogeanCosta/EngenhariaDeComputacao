import math

def prog_arit(num_ter, ter_ini, razao, nc='2'):
    """Mostra o primeiros num_ter de uma PA dados o termo inicial e a razão"""
    for i in range(num_ter-1):
        print(round(ter_ini, nc), end=', ')
        ter_ini = ter_ini + razao
    print(round(ter_ini, nc))


def prog_geom(num_ter, ter_ini, razao, nc=2):
    """Mostra o primeiros num_ter de uma PG dados o termo inicial e a razão"""
    for i in range(num_ter-1):
        print(round(ter_ini, nc), end=', ')
        ter_ini = ter_ini * razao
    print(round(ter_ini, nc))


def quad_perf(n):
    """Mostra os n primeiros quadrados perfeitos iniciando em 1"""
    for i in range(1, n):
        print(i**2, end=', ')
    print(n**2)


def fatorial(num):
    """Retorna o fatorial de num"""
    res = 1
    for i in range(2, num+1, 1):
        res = res * i
    return res


def mostre_fibo(num_ter, pri_ter=0, seg_ter=1):
    """Mostra os termos de uma sequência de Fibonacci dados o nº de termos"""
    print(pri_ter, ", ", seg_ter, sep='', end='')
    for i in range(num_ter - 2):
        print(", ", pri_ter + seg_ter, sep='', end='')
        pri_ter, seg_ter = seg_ter , pri_ter + seg_ter

    
def mdc(a, b):
    """Retorna o Máximo Divisor Comum de a e b"""
    while b != 0:
        a, b = b, a%b
    return a

def mmc(a, b):
    return a * b // mdc(a, b)

def div_milhares(num):
    """Recebe um inteiro e retorna uma string com os separadores de milhar"""
    snum = str(num)
    res = ""
    while len(snum) > 3:
        res = "." + snum[-3:] + res
        snum = snum[:-3]
    return snum + res


def extenso(num):
    """Recebe um inteiro entre 1 e 999 e retorna esse número por extenso"""
    if num == 100:
        return "cem"
    """Recebe um inteiro entre 1 e 999 e retorna uma string com este número por extenso"""
    cen = ["","cento","duzentos","trezentos","quatrocentos","quinhentos",
           "seiscentos","setecentos","oitocentos","novecentos"]
    dez = ["","dez","vinte","trinta","quarenta","cinquenta","sessenta",
           "setenta","oitenta","noventa"]
    uni = ["","um","dois","três","quatro","cinco","seis","sete","oito","nove"]
    dez_esp = ["","onze","doze","treze","quatorze","quinze","dezesseis",
               "dezessete","dezoito","dezenove"]
      
    c = num // 100
    d = num % 100 // 10
    u = num % 10

    res = ""
    if c > 0:
        res = res + cen[c]
        if d > 0 or u > 0:
            res += " e "
    if d == 1 and u > 0:
        return res + dez_esp[u]

    if d > 0:
        res = res + dez[d]
        if u > 0:
            res += " e "
    if u > 0:
        res = res + uni[u]

    return res

def mostre_divisores(num):
    for i in range(1, num//2+1):
        if num%i == 0:
            print(i, end=', ')
    print(num)

def str_divisores(num):
    res = ""
    for i in range(1, num//2+1):
        if num%i == 0:
            res += str(i) + ", "
    return res + str(num)


def mostre_divisores2(num):
    for i in range(1, int(math.sqrt(num))+1):
        if num%i == 0:
            print(i, num//i, end=' ')

def conte_divisores2(num):
    res = 1
    for i in range(1, num//2+1):
        if num%i == 0:
            res += 1
    return res

def some_divisores(num):
    res = num
    for i in range(1, num//2+1):
        if num%i == 0:
            res += i
    return res

def e_perfeito(num):
    return num == some_divisores(num) - num

def e_primo(num):
    for i in range(2, num//2+1):
        if num%i == 0:
            return False
    return True











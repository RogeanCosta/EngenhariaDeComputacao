import data

class Aluno:
    # Construtor
    def __init__(self, cod, nom, nasc, ap1=11.0, ap2=11.0):
        self.__codigo = cod
        self.__nome = nom
        self.__nasc = nasc
        self.__ap1 = ap1
        self.__ap2 = ap2

    # Métodos de acesso
    def get_codigo(self):
        return self.__codigo

    def get_nome(self):
        return self.__nome

    def get_nasc(self):
        return self.__nasc

    def get_ap1(self):
        return self.__ap1

    def get_ap2(self):
        return self.__ap2

    # Métodos modificadores
    def set_nome(self, novo_nome):
        if len(novo_nome) > 3:
            self.__nome = novo_nome

    def set_nasc(self, novo_nasc):
        if data.e_valida(novo_nasc.get_dia(), novo_nasc.get_mes(), novo_nasc.get_ano()):
            self.__nasc.set_data(novo_nasc.get_dia(),
                                 novo_nasc.get_mes(),
                                 novo_nasc.get_ano())

    def set_ap1(self, nova_ap1):
        if 0.0 <= nova_ap1 <= 10.0:
            self.__ap1 = nova_ap1
    
    def set_ap2(self, nova_ap2):
        if 0.0 <= nova_ap2 <= 10.0:
            self.__ap2 = nova_ap2
    
    # Métodos utilitários
    def media(self):
        ap1, ap2 = self.__ap1, self.__ap2
        if ap1 > 10.5:
            ap1 = 0.0
        if ap2 > 10.5:
            ap2 = 0.0
        return (2 * ap1 + 3 * ap2) / 5

    # Método de exibição
    def __str__(self):
        res = "{:06d} {:30s} {:s} ".format(
            self.__codigo, self.__nome[:30], str(self.__nasc))
        if self.__ap1 > 10.5:
            res += "      "
        else:
            res += "{:5.1f} ".format(self.__ap1)
        if self.__ap2 > 10.5:
            res += "      "
        else:
            res += "{:5.1f} ".format(self.__ap2)
        return res + "{:5.1f} ".format(self.media())

    # Métodos de comparação
    def __lt__(self, outro):
        return self.__codigo < outro.__codigo
    def __eq__(self, outro):
        return self.__codigo == outro.__codigo












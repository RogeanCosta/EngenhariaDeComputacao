class Celular:
    def __init__(self, ddd, num):
        if e_valido(ddd, num):
            self.__ddd = ddd
            if len(num) == 8:
                num = " " + num
            self.__num = num
        else:
            self.__ddd = "99"
            self.__num = "999999999"

    def get_ddd(self):
        return self.__ddd

    def get_num(self):
        return self.__num

    def set_ddd(self, ddd):
        if ddd.isdigit():
            self.__ddd = ddd[-2:]

    def set_num(self, num):
        if num.isdigit():
            self.__num = num[:9]

    def __str__(self):
        return "({:s}) {:s} {:s}-{:s}".format(
            self.__ddd,
            self.__num[0],
            self.__num[1:5],
            self.__num[5:])

def e_valido(ddd, num):
    if not ddd.isdigit() or not num.isdigit():
        return False
    if len(ddd) != 2:
        return False
    if len(num) < 8 or len(num) > 9:
        return False
    return True

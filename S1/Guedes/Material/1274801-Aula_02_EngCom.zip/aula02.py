Python 3.7.0 (v3.7.0:1bf9cc5093, Jun 27 2018, 04:59:51) [MSC v.1914 64 bit (AMD64)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> 3 + 4
7
>>> 3 ** 4
81
>>> 3 * 4
12
>>> 3 - 4
-1
>>> 3 / 4
0.75
>>> idade = 10
>>> print(3)
3
>>> print(a)
Traceback (most recent call last):
  File "<pyshell#7>", line 1, in <module>
    print(a)
NameError: name 'a' is not defined
>>> print(idade)
10
>>> idade = idade + 1
>>> print(idade)
11
>>> 
>>> 
>>> 
>>> 
>>> 
>>> forward(100)
Traceback (most recent call last):
  File "<pyshell#16>", line 1, in <module>
    forward(100)
NameError: name 'forward' is not defined
>>> import turtle
>>> turtle.forward(100)
>>> turtle.left(90)
>>> turtle.forward(100)
>>> turtle.left(90)
>>> turtle.forward(100)
>>> turtle.left(90)
>>> turtle.forward(100)
>>> turtle.left(90)
>>> turtle.clear()
>>> turtle.forward(120)
>>> turtle.left(60)
>>> turtle.forward(120)
>>> turtle.undo()
>>> turtle.left(120)
>>> turtle.undo()
>>> turtle.undo()
>>> turtle.left(120)
>>> turtle.forward(120)
>>> turtle.left(120)
>>> turtle.forward(120)
>>> turtle.left(120)
>>> turtle.clear()
>>> for i in range(10):
	print(i)

	
0
1
2
3
4
5
6
7
8
9
>>> for i in range(3, 10):
	print(i)

	
3
4
5
6
7
8
9
>>> for i in range(1, 11):
	print(i)

	
1
2
3
4
5
6
7
8
9
10
>>> for i in range(1, 101, 5):
	print(i)

	
1
6
11
16
21
26
31
36
41
46
51
56
61
66
71
76
81
86
91
96
>>> for a in range(4):
	turtle.forward(200)
	turtle.left(90)

	
>>> turtle.clear()
>>> for a in range(8):
	turtle.forward(100)
	turtle.left(45)

	
>>> turtle.speed(0)
>>> turtle.clear()
>>> for a in range(8):
	turtle.forward(100)
	turtle.left(45)

	
>>> turtle.speed("fastest")
>>> turtle.clear()
>>> for a in range(8):
	turtle.forward(100)
	turtle.left(45)

	
>>> turtle.pencolor("red")
>>> for a in range(8):
	turtle.forward(100)
	turtle.left(45)

	
>>> turtle.pensize(5)
>>> for a in range(8):
	turtle.forward(100)
	turtle.left(45)

	
>>> turtle.clear()
>>> turtle.begin_fill()
>>> for a in range(8):
	turtle.forward(100)
	turtle.left(45)

	
>>> turtle.end_fill()
>>> turtle.clear()
>>> turtle.fillcolor("orange")
>>> turtle.begin_fill()
>>> for a in range(8):
	turtle.forward(100)
	turtle.left(45)

	
>>> turtle.end_fill()
>>> turtle.reset()
>>> turtle.begin_fill()
>>> for a in range(8):
	turtle.forward(100)
	turtle.left(45)
	turtle.end_fill()

	
>>> turtle.reset()
>>> turtle.begin_fill()
>>> for a in range(8):
	turtle.forward(100)
	turtle.left(45)

	
>>> turtle.end_fill()
>>> turtle.reset()
>>> for i in range(3, 21):
	for j in range(i):
		turtle.forward(40)
		turtle.left(360/i)

		
>>> turtle.clear()
>>> for i in range(10, 0, -1):
	print(i)

	
10
9
8
7
6
5
4
3
2
1
>>> for i in range(20, 2, -1):
	for j in range(i):
		turtle.forward(40)
		turtle.left(360/i)

		
>>> turtle.clear()
>>> for i in range(20, 2, -1):
	turtle.begin_fill()
	for j in range(i):
		turtle.forward(40)
		turtle.left(360/i)
	turtle.end_fill()

	
>>> turtle.clear()
>>> turtle.speed(0)
>>> for i in range(3, 21, 1):
	turtle.begin_fill()
	for j in range(i):
		turtle.forward(40)
		turtle.left(360/i)
	turtle.end_fill()

	
>>> for i in range(3, 21, 1):
	turtle.begin_fill()
	for j in range(i):
		turtle.forward(40)
		turtle.left(360/i)
	turtle.end_fill()

	
>>> turtle.clear()
>>> for i in range(3, 21, 1):
	if i%2 != 0:
		turtle.begin_fill()
	for j in range(i):
		turtle.forward(40)
		turtle.left(360/i)
	if i%2 != 0:
		turtle.end_fill()

		
>>> turtle.clear()
>>> for i in range(20, 2, -1):
	if i%2 != 0:
		turtle.begin_fill()
	for j in range(i):
		turtle.forward(40)
		turtle.left(360/i)
	if i%2 != 0:
		turtle.end_fill()

		
>>> for i in range(20, 2, -1):
	if i%2 != 0:
		turtle.begin_fill()
	for j in range(i):
		turtle.forward(40)
		turtle.left(360/i)
	if i%2 != 0:
		turtle.end_fill()turtle.clear()
		
SyntaxError: invalid syntax
>>> turtle.clear()
>>> for i in range(20, 2, -1):
	if i%2 != 0:
		turtle.fillcolor("black")
	else:
		turtle.fillcolor("white")
	turtle.begin_fill()
	for j in range(i):
		turtle.forward(40)
		turtle.left(360/i)
	turtle.end_fill()

	
>>> for i in range(20, 2, -1):
	if i%2 != 0:
		turtle.begin_fill()
	for j in range(i):
		turtle.forward(40)
		turtle.left(360/i)
	if i%2 != 0:
		turtle.end_fill()turtle.clear()
		
SyntaxError: invalid syntax
>>> turtle.clear()
>>> for i in range(20, 2, -1):
	if i%2 == 0:
		turtle.begin_fill()
	for j in range(i):
		turtle.forward(40)
		turtle.left(360/i)
	if i%2 != 0:
		turtle.end_fill()

		
>>> turtle.clear()
>>> for i in range(20, 2, -1):
	if i%2 == 0:
		turtle.fillcolor("black")
	else:
		turtle.fillcolor("white")
	turtle.begin_fill()
	for j in range(i):
		turtle.forward(40)
		turtle.left(360/i)
	turtle.end_fill()

	
>>> 

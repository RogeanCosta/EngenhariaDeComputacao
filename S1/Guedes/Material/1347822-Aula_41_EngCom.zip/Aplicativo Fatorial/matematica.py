def prog_arit(num_ter, ter_ini, razao):
    """Mostra os primeiros num_ter de uma progressão aritmética dado o termo inicial e a razão"""
    for i in range(num_ter-1):
        print(ter_ini, end=', ')
        ter_ini = ter_ini + razao
    print(ter_ini)


def prog_geom(num_ter, ter_ini, razao):
    """Mostra os primeiros num_ter de uma progressão geométrica dado o termo inicial e a razão"""
    for i in range(num_ter-1):
        print(ter_ini, end=', ')
        ter_ini = ter_ini * razao
    print(ter_ini)


def quad_perf(n):
    """Mostra o n primeiros quadrados perfeitos iniciando em 1"""
    for i in range(1, n):
        print(i**2, end=', ')
    print(n*n)


def fatorial(n):
    """Calcula e retorna o fatorial de n"""
    res = 1
    for i in range(n, 1, -1):
        res = res * i
    return res

def fibonacci(num_ter, pri_ter=0, seg_ter=1):
    """Mostra o n primeiros termos da sequência de Fibonacci dados, opcionalmente, o primeiro e segundos termos"""
    print(pri_ter, seg_ter, sep=', ', end='')
    for i in range(num_ter - 2):
        print(', ', pri_ter + seg_ter, sep='', end='')
        pri_ter, seg_ter = seg_ter, pri_ter + seg_ter

def mostre_divisores(n):
    """Mostra os divisores de n"""
    for i in range(1, n//2+1):
        if n%i == 0:
            print(i, end=', ')
    print(n)

def conte_divisores(n):
    """Retorna o número de divisores de n"""
    res = 1
    for i in range(1, n//2+1):
        if n%i == 0:
            res = res + 1
    return res

def é_primo(n):
    """Retorna True se n é primo, False caso contrário"""
    if n == 1: return False
    for i in range(2, n//2+1):
        if n%i == 0:
            return False
    return True

def mostre_primos(ini, fim):
    """Mostra os números primos no intervalo fechado [ini,fim]"""
    for i in range(ini, fim+1):
        if é_primo3(i):
            print(i, end=' ')

def extenso(num):
    """Retorna uma string com num (1 <= num <= 999) escrito por extenso"""

    if num == 100:
        return "cem"
    
    uni = ["", "um","dois","três","quatro","cinco","seis","sete","oito","nove"]
    dez = ["", "dez","vinte","trinta","quarenta","cinquenta","sessenta",
           "setenta","oitenta","noventa"]
    cen = ["", "cento","duzentos","trezentos","quatrocentos","quinhentos",
           "seiscentos","setecentos","oitocentos","novecentos"]
    dez_esp = ["","onze","doze","treze","quatorze","quinze","dezesseis",
               "dezessete","dezoito","dezenove"]

    c = num // 100
    d = num % 100 // 10
    u = num % 10

    res = ""

    if c > 0:
        res = res + cen[c]
        if d > 0 or u > 0:
            res = res + " e "

    if d == 1 and u > 0:
        return res + dez_esp[u]    
    
    if d > 0:
        res = res + dez[d]
        if u > 0:
            res = res + " e "

    if u > 0:
        res = res + uni[u]
        
    return res
        
    
##for i in range(1, 1000):
##    print(extenso(i))

def sep_milhares(num):
    snum = str(num)
    res = ""

    while len(snum) > 3:
        res = "." + snum[-3:] + res
        snum = snum[0:-3]

    return snum + res

#print(sep_milhares(132356456789123456789))







    












import turtle as tat
import time
import math

def koch(tam, ger):
    if ger == 0:
        tat.forward(tam)
        return
    koch(tam/3, ger-1)
    tat.left(60)
    koch(tam/3, ger-1)
    tat.right(120)
    koch(tam/3, ger-1)
    tat.left(60)
    koch(tam/3, ger-1)

##tat.penup()
##tat.backward(300)
##tat.pendown()
##tat.speed(0)
##for i in range(3):
##    koch(300, 4)
##    tat.right(120)

def koch_2(tam, ger):
    if ger == 0:
        tat.forward(tam)
        return
    koch_2(tam/3, ger-1)
    tat.left(90)
    for i in range(2):
        koch_2(tam/3, ger-1)
        tat.right(90)
    koch_2(tam/3, ger-1)
    tat.left(90)
    koch_2(tam/3, ger-1)

##tat.penup()
##tat.backward(300)
##tat.pendown()
##tat.speed(0)
##koch_2(600, 6)

def sierp(tam, ger):
    if ger == 0:
        tat.forward(tam)
        return
    sierp(tam/2, ger-1)
    tat.left(120)
    tat.forward(tam/2)
    tat.right(120)
    sierp(tam/2, ger-1)
    tat.right(120)
    tat.forward(tam/2)
    tat.left(120)
    sierp(tam/2, ger-1)
    
#tat.tracer(0,0)
##tat.penup()
##tat.backward(300)
##tat.left(90)
##tat.backward(250)
##tat.right(90)
##tat.pendown()
##while True:
##    for i in range(7):
##        sierp(600, i)
##    #    tat.update()
##        time.sleep(2)
##        tat.backward(600)
##        tat.clear()

def cesaro(tam, ger):
    if ger == 0:
        tat.forward(tam)
        return
    x = tam / (2 + 2 * math.cos(85*math.pi/180))
    cesaro(x, ger-1)
    tat.left(85)
    cesaro(x, ger-1)
    tat.right(170)
    cesaro(x, ger-1)
    tat.left(85)
    cesaro(x, ger-1)

tat.speed(0)
for i in range(4):
    cesaro(300,6)
    tat.left(90)











#koch(600, 5)

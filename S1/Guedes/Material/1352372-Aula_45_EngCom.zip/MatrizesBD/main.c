#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void preenche_matriz(int nl, int nc, int mat[nl][nc])
{
    int i, j;
    for(i=0; i<nl; i++)
        for(j=0; j<nc; j++)
            mat[i][j] = rand()%10;
}

void mostre_matriz(int nl, int nc, int mat[nl][nc])
{
    int i, j;
    for(i=0; i<nl; i++) {
        printf("%c", 179);
        for(j=0; j<nc; j++)
            printf("%3d ", mat[i][j]);
        printf("%c\n",179);
    }
}

int main()
{
    srand(time(NULL));
    int matriz[100][100];
    int nl = 5, nc = 8;
    preenche_matriz(nl, nc, matriz);
    mostre_matriz(nl, nc, matriz);
    return 0;
}

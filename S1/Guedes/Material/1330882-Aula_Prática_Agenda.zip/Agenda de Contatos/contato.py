import celular
import aniversario

class Contato:
    def __init__(self, nom, cel, ani):
        self.__nome = nom
        self.__cel = cel
        self.__ani = ani

    def get_nome(self):
        return self.__nome

    def get_cel(self):
        return self.__cel

    def get_ani(self):
        return self.__ani

    def __str__(self):
        return "{:12s}  {:s}  {:s}".format(
            self.__nome[:12],
            str(self.__cel),
            str(self.__ani))


    

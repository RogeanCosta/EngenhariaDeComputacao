import matematica as mat
import time

while True:
    try:
        print("\n***********************")
        print("* Cálculo do Fatorial *")
        print("***********************\n")
        snum = input("  Digite um número inteiro >= 0 (negativo para sair): ")
        num = int(snum)
        if num < 0:
            print("\n  ** FIM DO APLICATIVO ***")
            time.sleep(3)
            break
        print("\n  ", num, "! = ", sep='', end='')
        if 1 < num <= 10:
            for i in range(num, 1, -1):
                print(i, " x ", sep='', end='')
            print("1 = ", end='')
        print(mat.fatorial(num))
    except ValueError:
        print("\n  ** FAVOR DIGITAR VALORES INTEIROS **\n")


import tkinter as tk
from tkinter import ttk

win = tk.Tk()
win.title("Animais")

rbuVar = tk.IntVar()
def muda_imagem():
    global rbuVar
    if rbuVar.get() == 0:
        tela.create_image(66,66,image=phi_bird)
    elif rbuVar.get() == 1:
        tela.create_image(66,66,image=phi_cat)
    elif rbuVar.get() == 2:
        tela.create_image(66,66,image=phi_dog)
    elif rbuVar.get() == 3:
        tela.create_image(66,66,image=phi_pig)
    elif rbuVar.get() == 4:
        tela.create_image(66,66,image=phi_rabbit)

rbuBird = ttk.Radiobutton(win, text='Papagaio', value=0, variable=rbuVar, width=10, command=muda_imagem)
rbuBird.grid(column=0, row=0)

rbuCat = ttk.Radiobutton(win, text='Gato', value=1, variable=rbuVar, width=10, command=muda_imagem)
rbuCat.grid(column=0, row=1)

rbuDog = ttk.Radiobutton(win, text='Cachorro', value=2, variable=rbuVar, width=10, command=muda_imagem)
rbuDog.grid(column=0, row=2)

rbuPig = ttk.Radiobutton(win, text='Porco', value=3, variable=rbuVar, width=10, command=muda_imagem)
rbuPig.grid(column=0, row=3)

rbuRabbit = ttk.Radiobutton(win, text='Coelho', value=4, variable=rbuVar, width=10, command=muda_imagem)
rbuRabbit.grid(column=0, row=4)

phi_bird = tk.PhotoImage(file="Bird.gif")
phi_cat = tk.PhotoImage(file="Cat.gif")
phi_dog = tk.PhotoImage(file="Dog.gif")
phi_pig = tk.PhotoImage(file="Pig.gif")
phi_rabbit = tk.PhotoImage(file="Rabbit.gif")

tela = tk.Canvas(win, width=129, height=129, bg="lightblue")
tela.grid(column=1, row=0, rowspan=5)

tela.create_image(66,66,image=phi_bird)

win.resizable(0,0)
win.mainloop()

import random
import data
import aluno

def gere_nome():
    nomes = ('Aline', 'Ana', 'Beatriz', 'Bernardo', 'Bruno', 'Camila', 'Carlos', 'Cecília',
             'Davi', 'Eduardo', 'Felipe', 'Francisco', 'Gabriel', 'Gérson', 'Heitor', 'Henrique',
             'Ingrid', 'Isabela', 'Júlia', 'Larissa', 'Laura', 'Leonardo', 'Lorena', 'Marcelo',
             'Márcia', 'Marcos', 'Mariana', 'Milena', 'Patrícia', 'Pedro', 'Priscila', 'Renato',
             'Ricardo', 'Rodrigo', 'Ronaldo', 'Samuel', 'Sérgio', 'Sofia', 'Tiago', 'Vinícius')
    sobrenomes = ('Abreu', 'Albuquerque', 'Almeida', 'Alencar', 'Alves', 'Amaral', 'Amorim',
                  'Andrade', 'Antunes', 'Arantes', 'Araújo', 'Arruda', 'Azevedo', 'Barros',
                  'Bastos', 'Batista', 'Bezerra', 'Brandão', 'Brito', 'Cabral', 'Campos',
                  'Cardoso', 'Carneiro', 'Carvalho', 'Castro', 'Cavalcante', 'Chagas', 'Chaves',
                  'Correia', 'Costa', 'Cruz', 'Dantas', 'Diniz', 'Duarte', 'Esteves', 'Fagundes',
                  'Fernandes', 'Ferraz', 'Ferreira', 'Figueiredo', 'Fonseca', 'Franco', 'Freire',
                  'Freitas', 'Furtado', 'Gomes', 'Gonçalves', 'Guedes', 'Guerra', 'Guimarães',
                  'Liberato', 'Marinho', 'Marques', 'Martins', 'Medeiros', 'Melo', 'Menezes',
                  'Monteiro', 'Montenegro', 'Moraes', 'Moreira', 'Moura', 'Nogueira', 'Noronha',
                  'Novaes', 'Oliveira', 'Pereira', 'Pinto', 'Resende', 'Ribeiro', 'Rios',
                  'Sampaio', 'Santana', 'Santos', 'Torres', 'Trindade', 'Vasconcelos', 'Vargas')
    res = random.choice(nomes) + " "
    sn1 = random.choice(sobrenomes)
    sn2 = random.choice(sobrenomes)
    while sn1 == sn2:
        sn2 = random.choice(sobrenomes)
    
    return res + sn1 + " " + sn2

def gere_data():
    return data.Data(random.randint(1,28), random.randint(1,12), random.randint(1980, 2000))

def gere_aluno(cod):
    return aluno.Aluno(cod, gere_nome(), gere_data(),
                       random.randint(50, 100)/10,
                       random.randint(50, 100)/10)

##lis_alu = []
##for i in range(1, 21):
##    lis_alu.append(gere_aluno(i))
##
##for alu in lis_alu:
##    print(alu)
##
##print(30*"-")
##
##for alu in sorted(lis_alu, key=lambda alu : alu.get_nome()):
##    print(alu)
##
##print(30*"-")
##
##for alu in sorted(lis_alu, key=lambda alu : alu.get_nasc()):
##    print(alu)
##
##print(30*"-")
##
##for alu in sorted(lis_alu, key=lambda alu : alu.media(), reverse=True):
##    print(alu)













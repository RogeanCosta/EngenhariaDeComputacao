class Hora:
    # CONSTRUTOR
    def __init__(self, hora=0, minuto=0, segundo=0):
        if Hora.e_valida(hora, minuto, segundo):
            self.__hora = hora
            self.__minuto = minuto
            self.__segundo = segundo
        else:
            self.__hora = 0
            self.__minuto = 0
            self.__segundo = 0
            

    # MÉTODOS DE ACESSO
    def get_hora(self):
        return self.__hora

    def get_minuto(self):
        return self.__minuto

    def get_segundo(self):
        return self.__segundo

    # MÉTODOS MODIFICADORES
    def set_hora(self, nova_hora):
        if 0 <= nova_hora < 24:
            self.__hora = nova_hora

    def set_minuto(self, novo_minuto):
        if 0 <= novo_minuto < 60:
            self.__minuto = novo_minuto

    def set_segundo(self, novo_segundo):
        if 0 <= novo_segundo < 60:
            self.__segundo = novo_segundo

    # MÉTODOS UTILITÁRIOS

    @staticmethod
    def e_valida(hora, minuto, segundo):
        return 0 <= hora < 24 and 0 <= minuto < 60 and 0 <= segundo < 60

    def mais_um_segundo(self):
        self.__segundo += 1
        if self.__segundo == 60:
            self.__segundo = 0
            self.__minuto += 1
            if self.__minuto == 60:
                self.__minuto = 0
                self.__hora += 1
                if self.__hora == 24:
                    self.__hora = 0

    # MÉTODO DE EXIBIÇÃO DE INSTÂNCIA
    def __str__(self):
        return "{:02d}:{:02d}:{:02d}".format(self.__hora, self.__minuto, self.__segundo)

    def str_12(self):
        return "{:02d}:{:02d}:{:02d} {:s}".format(
            12 if self.__hora == 0 or self.__hora == 12 else self.__hora%12,
            self.__minuto,
            self.__segundo,
            "AM" if self.__hora < 12 else "PM")
        
    # MÉTODOS DE COMPARAÇÃO
    def __lt__(self, outra):
        return [self.__hora, self.__minuto, self.__segundo] < [outra.__hora, outra.__minuto, outra.__segundo]




    

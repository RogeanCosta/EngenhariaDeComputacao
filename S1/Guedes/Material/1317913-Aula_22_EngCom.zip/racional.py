class Racional:
    # Construtor
    def __init__(self, p=0, q=1):
        if q != 0:
            if q > 0:
                self.__p = p
                self.__q = q
            else:
                self.__p = -p
                self.__q = -q
            if self.__p == 0:
                self.__q = 1
        else:
            self.__p = 0
            self.__q = 1

    def get_p(self):
        return self.__p

    def get_q(self):
        return self.__q

    def set_p(self, novo_p):
        self.__p = novo_p

    def set_q(self, novo_q):
        if novo_q != 0: 
            self.__q = novo_q

    def mdc(a, b):
        while b != 0:
            a, b = b, a%b
        return a

    def simplifica(self):
        m = Racional.mdc(self.__p, self.__q)
        self.__p = self.__p // m
        self.__q = self.__q // m

    def __add__(self, outro):
        p = self.__p * outro.__q + self.__q * outro.__p
        q = self.__q * outro.__q
        return Racional(p, q)

    def __str__(self):
        if self.__q == 1:
            return str(self.__p)
        else:
            return "{:d}/{:d}".format(self.__p, self.__q)









    





import turtle
import random
import time

def quadrado_arred(quem, tam_lado, raio, esp=1, corL='black', corP='white'):
    quem.color(corL, corP)
    quem.pensize(esp)
    quem.penup()
    quem.forward(raio)
    quem.pendown()
    quem.begin_fill()
    for i in range(4):
        quem.forward(tam_lado - 2 * raio)
        quem.circle(raio, 90)
    quem.end_fill()
    quem.penup()
    quem.backward(raio)
    quem.pendown()

turtle.tracer(0,0)

tat1 = turtle.Turtle()
tat1.backward(100)
tat1.hideturtle()
tat2 = turtle.Turtle()
tat2.hideturtle()
tat3 = turtle.Turtle()
tat3.backward(100)
tat3.left(90)
tat3.backward(100)
tat3.right(90)
tat3.hideturtle()
tat4 = turtle.Turtle()
tat4.left(90)
tat4.backward(100)
tat4.right(90)
tat4.hideturtle()

while True:
    ang = 0
    for j in range(3):
        if j == 0:
           pc = "blue"
        elif j == 1:
            pc = "red"
        else:
            pc = "orange"
        for i in range(50):
            quadrado_arred(tat1, 100, ang, 1, pc, pc)
            tat1.setposition(tat1.xcor()-2, tat1.ycor()+2)
            quadrado_arred(tat2, 100, ang, 1, pc, pc)
            tat2.setposition(tat2.xcor()+2, tat2.ycor()+2)
            quadrado_arred(tat3, 100, ang, 1, pc, pc)
            tat3.setposition(tat3.xcor()-2, tat3.ycor()-2)
            quadrado_arred(tat4, 100, ang, 1, pc, pc)
            tat4.setposition(tat4.xcor()+2, tat4.ycor()-2)
            turtle.update()
            time.sleep(0.05)
            tat1.clear()
            tat2.clear()
            tat3.clear()
            tat4.clear()
        for i in range(50):
            quadrado_arred(tat1, 100, ang, 1, pc, pc)
            tat1.setposition(tat1.xcor()+2, tat1.ycor()-2)
            tat1.left(7.2)
            quadrado_arred(tat2, 100, ang, 1, pc, pc)
            tat2.setposition(tat2.xcor()-2, tat2.ycor()-2)
            tat2.left(7.2)
            quadrado_arred(tat3, 100, ang, 1, pc, pc)
            tat3.setposition(tat3.xcor()+2, tat3.ycor()+2)
            tat3.left(7.2)
            quadrado_arred(tat4, 100, ang, 1, pc, pc)
            tat4.setposition(tat4.xcor()-2, tat4.ycor()+2)
            tat4.left(7.2)
            turtle.update()
            time.sleep(0.05)
            tat1.clear()
            tat2.clear()
            tat3.clear()
            tat4.clear()







        

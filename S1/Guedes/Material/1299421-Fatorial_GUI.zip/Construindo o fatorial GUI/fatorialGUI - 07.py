""" LIMPANDO A SAÍDA QUANDO A ENTRADA É ALTERADA """

import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
import matematica as mat

win = tk.Tk()
win.title("Fatorial - IFCE")

rot1 = tk.ttk.Label(win, text=" O fatorial de ")  
rot1.grid(column=0, row=0, padx=5, pady=5)        

entrada = tk.StringVar()                              
ent = ttk.Entry(win, width=6, textvariable=entrada)   
ent.grid(column=1, row=0, padx=5, pady=5)             
ent.focus()                                           

rot2 = ttk.Label(win, text=" é igual a ")             
rot2.grid(column=2, row=0)                            

saida = tk.StringVar()                                  
sai = ttk.Entry(win, width=30, textvariable=saida)      
sai.grid(column=3, row=0, padx=5, pady=5)               

def calculo():                                                          
    try:                                                                
        ent_val = int(entrada.get())
        if ent_val < 0:
            messagebox.showinfo("Entrada inválida",                     
                                "Números negativos não são válidos")
        else:           
            sai_val = mat.fatorial(ent_val)                             
            saida.set(sai_val)                                          
    except ValueError:                                                  
        messagebox.showinfo("Entrada inválida",                         
                            "Digite um número inteiro positivo")        
        entrada.set("")                                                 
    ent.focus()                                                         
        
calcular = ttk.Button(win, text=" Calcular ", command=calculo)          
calcular.grid(column=1, row=1, pady=10)                                          # <--

def fechar():                                           
    win.destroy()                                       
    
sair = ttk.Button(win, text=" Sair ", command=fechar)   
sair.grid(column=3, row=1, pady=10)                     

def limpa(event):               # <--
    saida.set("")               # <--
    ent.focus()                 # <--
ent.bind("<Key>", limpa)        # <--

win.mainloop()














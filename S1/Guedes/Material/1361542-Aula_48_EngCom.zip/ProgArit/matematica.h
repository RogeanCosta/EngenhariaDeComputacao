#include <ctype.h>
#include <string.h>

void prog_arit(int num_ter, float ter_ini, float razao)
{
    int i;
    for(i=0; i<num_ter-1; i++)
    {
        printf("%.2f, ", ter_ini);
        ter_ini = ter_ini + razao;
    }
    printf("%.2f\n", ter_ini);
}

void quad_perf(int n)
{
    int i;
    for(i=1; i<n; i++)
        printf("%d, ", i*i);
    printf("%d\n", n*n);
}

unsigned long long fatorial(int n)
{
    unsigned long long res = 1;
    while(n > 1)
    {
        res *= n;
        n--;
    }
    return res;
}

void mostre_divisores(int n)
{
    int i;
    for(i=1; i<=n/2; i++)
        if(n%i == 0)
            printf("%d, ", i);
    printf("%d\n", n);
}

int conte_divisores(int n)
{
    int i, res = 1;
    for(i=1; i<=n/2; i++)
        if(n%i == 0)
            res++;
    return res;
}

int e_primo(int n)
{
    int i;
    if(n == 1) return 0;
    for(i=2; i <= n/2; i++)
        if(n%i == 0)
            return 0;
    return 1;
}

void mostre_primos(int ini, int fim)
{
    int i;
    for(i=ini; i <= fim; i++)
        if(e_primo(i))
            printf("%d ", i);
}

int e_inteiro(char *snum)
{
    int i = 0;
    if(snum[i] == '-' || snum[i] == '+')
        i++;
    while(snum[i])
    {
        if(!isdigit(snum[i]))
            return 0;
        i++;
    }
    return 1;
}

int e_real(char *snum)
{
    int np = 0;
    if(*snum == '-' || *snum == '+')
        snum++;
    while(*snum)
    {
        if(!isdigit(*snum)) {
            if(*snum != '.' || np > 0)
                return 0;
            else
                np++;
        }
        snum++;
    }
    return 1;
}



void div_milhar(unsigned long long num, char *snum)
{
    int i;
    int np; // n�mero de pontos
    int ts; // tamanho da string
    int pu; // puxador
    sprintf(snum, "%I64u", num);
    ts = strlen(snum);
    np = (ts-1) / 3;
    snum[ts + np] = '\0';
    pu = ts + np - 1;
    while(np > 0) {
        for(i=0; i<3; i++)
        {
            snum[pu] = snum[pu-np];
            pu--;
        }
        snum[pu] = '.';
        if(np > 1)
            pu--;
        np--;
    }
}








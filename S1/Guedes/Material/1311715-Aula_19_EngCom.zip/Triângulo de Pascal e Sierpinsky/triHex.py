import turtle
import geom
import math

def triangDePascal(altura):
    res = [[1],[1,1]]
    for i in range(1,altura-1):
        lis = [1]
        y = 0
        for j in range(i):
            lis.append(res[i][y] + res[i][y+1])
            y = y+1
        lis.append(1)
        res.append(lis)
    return res

def linhaDeHex(numHex, tamLadoHex):
    for i in range(numHex):
        geom.polígonoRegular (6,tamLadoHex)
        turtle.right (60)
        turtle.back(tamLadoHex)
        turtle.left (120)
        turtle.forward(tamLadoHex)
        turtle.right (60)
    turtle.penup ()
    turtle.right(90)
    turtle.forward (numHex * 2 * tamLadoHex * math.cos(math.radians (30)))
    turtle.left (90)
    turtle.pendown ()
        
def triangHex(numHex, tamLado):
    pascal = triangDePascal(numHex)
    for i in range(1,numHex+1):
        linhaDeHex(i, tamLado)
        turtle.penup ()
        turtle.left(60)
        turtle.backward (tamLado)
        turtle.right (60)
        turtle.backward (tamLado)
        turtle.pendown()

##turtle.left(90)
##turtle.penup()
##turtle.forward(200)
##turtle.pendown()
##turtle.speed(0)
##triangHex(32, 10)

def sierpPascal(altura,tamLado,modulo):
    pascal = triangDePascal (altura)
    turtle.tracer(0,0)
    up = 0
    for i in pascal:
        for j in i:
            if up%500 == 0:
                turtle.update()
            up += 1
            if j%modulo == 0:
                geom.polígonoRegular(6,tamLado)
            else:
                geom.polígonoRegular(6,tamLado,corp='black')
            turtle.right (60)
            turtle.backward(tamLado)
            turtle.left (120)
            turtle.forward(tamLado)
            turtle.right (60)
        turtle.penup ()
        turtle.right(90)
        turtle.forward (len(i) * 2 * tamLado * math.cos(math.radians (30)))
        turtle.left (150)
        turtle.backward(tamLado)
        turtle.right (60)
        turtle.backward(tamLado)
        turtle.pendown ()
        turtle.update()

turtle.left (90)
turtle.penup ()
turtle.forward (250)
turtle.pendown ()
##tp = triangDePascal(15)
##for i in tp:
##    print(i)
sierpPascal(128,3,6)
turtle.hideturtle()
turtle.done()

##turtle.speed (3)
##turtle.left (90)
#triangHex(64,5)
#linhaDeHex(1,40)










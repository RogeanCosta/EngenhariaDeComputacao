import turtle as tat
import time
import math
import random

def koch(tam, ger):
    if ger == 0:
        tat.forward(tam)
        return
    koch(tam/3, ger-1)
    tat.left(60)
    koch(tam/3, ger-1)
    tat.right(120)
    koch(tam/3, ger-1)
    tat.left(60)
    koch(tam/3, ger-1)

##tat.penup()
##tat.backward(300)
##tat.pendown()
##tat.speed(0)
##for i in range(3):
##    koch(300, 4)
##    tat.right(120)

def koch_2(tam, ger):
    if ger == 0:
        tat.forward(tam)
        return
    koch_2(tam/3, ger-1)
    tat.left(90)
    for i in range(2):
        koch_2(tam/3, ger-1)
        tat.right(90)
    koch_2(tam/3, ger-1)
    tat.left(90)
    koch_2(tam/3, ger-1)

##tat.penup()
##tat.backward(300)
##tat.pendown()
##tat.speed(0)
##koch_2(600, 6)

def sierp(tam, ger):
    if ger == 0:
        tat.forward(tam)
        return
    sierp(tam/2, ger-1)
    tat.left(120)
    tat.forward(tam/2)
    tat.right(120)
    sierp(tam/2, ger-1)
    tat.right(120)
    tat.forward(tam/2)
    tat.left(120)
    sierp(tam/2, ger-1)
    
##tat.tracer(0,0)
##tat.penup()
##tat.backward(300)
##tat.left(90)
##tat.backward(250)
##tat.right(90)
##tat.pendown()
##while True:
##    for i in range(9):
##        sierp(600, i)
##        tat.update()
##        time.sleep(2)
##        tat.backward(600)
##        tat.clear()

def cesaro(tam, ger):
    if ger == 0:
        tat.forward(tam)
        return
    x = tam / (2 + 2 * math.cos(85*math.pi/180))
    cesaro(x, ger-1)
    tat.left(85)
    cesaro(x, ger-1)
    tat.right(170)
    cesaro(x, ger-1)
    tat.left(85)
    cesaro(x, ger-1)

##tat.speed(0)
##for i in range(4):
##    cesaro(300,6)
##    tat.left(90)

def bacia_esq(tam, ger):
    if ger == 0:
        tat.forward(tam)
        return
    tat.left(60)
    bacia_dir(tam/2, ger-1)
    tat.right(60)
    bacia_esq(tam/2, ger-1)
    tat.right(60)
    bacia_dir(tam/2, ger-1)
    tat.left(60)

def bacia_dir(tam, ger):
    if ger == 0:
        tat.forward(tam)
        return
    tat.right(60)
    bacia_esq(tam/2, ger-1)
    tat.left(60)
    bacia_dir(tam/2, ger-1)
    tat.left(60)
    bacia_esq(tam/2, ger-1)
    tat.right(60)



##tat.speed(0)
##tat.penup()
##tat.backward(300)
##tat.left(90)
##tat.backward(250)
##tat.right(90)
##tat.pendown()
##bacia_esq(600,8)


def triang(tl):
    tat.begin_fill()
    for i in range(3):
        tat.forward(tl)
        tat.left(120)
    tat.end_fill()

def sierp_ori(tam, ger):
    if ger == 0:
        triang(tam)
        return
    for i in range(3):
        sierp_ori(tam/2, ger-1)
        tat.forward(tam)
        tat.left(120)

##tat.speed(0)
##tat.penup()
##tat.backward(300)
##tat.left(90)
##tat.backward(250)
##tat.right(90)
##tat.pendown()

def jogo_do_caos(tam):
    tat.penup()
    a = tat.position()
    tat.dot(3)
    tat.forward(tam)
    b = tat.position()
    tat.dot(3)
    tat.left(120)
    tat.forward(tam)
    c = tat.position()
    tat.dot(3)
    tat.goto(random.randint(-400,400), random.randint(-400,400))
    tat.dot(5)
    for i in range(10000):
        rs = random.randint(1,3)
        if rs == 1:
            tat.setheading(tat.towards(a))
            tat.forward(tat.distance(a) / 2)
            tat.pencolor("blue")
            tat.dot(3)
        if rs == 2:
            tat.setheading(tat.towards(b))
            tat.forward(tat.distance(b) / 2)
            tat.pencolor("red")
            tat.dot(3)
        if rs == 3:
            tat.setheading(tat.towards(c))
            tat.forward(tat.distance(c) / 2)
            tat.pencolor(0,0,0)
            tat.dot(3)
        tat.update()

##tat.tracer(0,0)
##jogo_do_caos(600)
    
def arvore(tam, ger):
    if ger == 0:
        return
    tat.forward(tam)
    tat.left(20)
    arvore(0.8*tam, ger-1)
##    tat.forward(0.8*tam)
##    tat.backward(0.8*tam)
    tat.right(40)
    arvore(0.8*tam, ger-1)
##    tat.forward(0.8*tam)
##    tat.backward(0.8*tam)
    tat.left(20)
    tat.backward(tam)

tat.left(90)
tat.penup()
tat.back(250)
tat.pendown()
arvore(100,8)

import turtle
import random

lista_tat = []
lista_cor = ["blue", "red", "yellow", "green", "orange"]

for i in range(10):
    lista_tat.append(turtle.Turtle("turtle"))
    lista_tat[i].color(random.choice(lista_cor))
    
lista_tat[0].pensize(2)

turtle.tracer(0,0)
for i in range(2000):
    for tat in lista_tat:
        tat.forward(5)
        tat.left(random.randint(-65, 45))
    turtle.update()

lista_tat[0].pensize(10)
lista_tat[0].goto(0,0)
turtle.update()

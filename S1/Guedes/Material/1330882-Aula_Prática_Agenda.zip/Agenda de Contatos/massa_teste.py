import random
import contato
import aniversario
import celular

def nome_ja_cadastrado(lis, nom):
    for con in lis:
        if nom == con.get_nome():
            return True
    return False

def gere_lis_contatos(num_con):
    lis_con = []
    nomes = ('Aline', 'Ana', 'Beatriz', 'Bernardo', 'Bruno', 'Camila', 'Carlos', 'Cecília',
             'Davi', 'Eduardo', 'Felipe', 'Francisco', 'Gabriel', 'Gérson', 'Heitor', 'Henrique',
             'Ingrid', 'Isabela', 'Júlia', 'Larissa', 'Laura', 'Leonardo', 'Lorena', 'Marcelo',
             'Márcia', 'Marcos', 'Mariana', 'Milena', 'Patrícia', 'Pedro', 'Priscila', 'Renato',
             'Ricardo', 'Rodrigo', 'Ronaldo', 'Samuel', 'Sérgio', 'Sofia', 'Tiago', 'Vinícius')
    sobrenomes = ('Abreu', 'Albuquerque', 'Almeida', 'Alencar', 'Alves', 'Amaral', 'Amorim',
                  'Andrade', 'Antunes', 'Arantes', 'Araújo', 'Arruda', 'Azevedo', 'Barros',
                  'Bastos', 'Batista', 'Bezerra', 'Brandão', 'Brito', 'Cabral', 'Campos',
                  'Cardoso', 'Carneiro', 'Carvalho', 'Castro', 'Cavalcante', 'Chagas', 'Chaves',
                  'Correia', 'Costa', 'Cruz', 'Dantas', 'Diniz', 'Duarte', 'Esteves', 'Fagundes',
                  'Fernandes', 'Ferraz', 'Ferreira', 'Figueiredo', 'Fonseca', 'Franco', 'Freire',
                  'Freitas', 'Furtado', 'Gomes', 'Gonçalves', 'Guedes', 'Guerra', 'Guimarães',
                  'Liberato', 'Marinho', 'Marques', 'Martins', 'Medeiros', 'Melo', 'Menezes',
                  'Monteiro', 'Montenegro', 'Moraes', 'Moreira', 'Moura', 'Nogueira', 'Noronha',
                  'Novaes', 'Oliveira', 'Pereira', 'Pinto', 'Resende', 'Ribeiro', 'Rios',
                  'Sampaio', 'Santana', 'Santos', 'Torres', 'Trindade', 'Vasconcelos', 'Vargas')

    for i in range(num_con):
        nome = random.choice(nomes)
        while nome_ja_cadastrado(lis_con, nome):
            nome = random.choice(nomes)
        sd = random.randint(0,99)
        if sd < 80:
            ddd = "85"
        else:
            ddd = str(random.randint(11, 95))
        pre = str(random.randint(85, 95)) + str(random.randint(10,99))
        num = str(random.randint(1000,9999))
        dia = random.randint(1,29)
        mes = random.randint(1,12)

        lis_con.append(contato.Contato(nome,
                                       celular.Celular(ddd, "9"+pre+num),
                                       aniversario.Aniversario(dia, mes)))
    return sorted(lis_con, key=lambda con : con.get_nome())


lista_de_contatos = gere_lis_contatos(20)

for i in lista_de_contatos:
    print(i)




        

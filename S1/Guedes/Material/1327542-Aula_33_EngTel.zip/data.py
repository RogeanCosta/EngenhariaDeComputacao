class Data:
    # Construtor
    def __init__(self, dia=15, mes=10, ano=1582):
        """
        Construtor de objetos do tipo Data
        :param dia: dia do mês
        :param mes: mês
        :param ano: ano
        """
        if e_valida(dia, mes, ano):
            self.__dia = dia
            self.__mes = mes
            self.__ano = ano
        else:
            self.__dia = 1
            self.__mes = 1
            self.__ano = 1900

    # Métodos de acesso
    def get_dia(self):
        """
        Método de acesso ao campo dia
        :return: o dia
        """
        return self.__dia

    def get_mes(self):
        """
        Método de acesso ao campo mês
        :return:  o mês
        """
        return self.__mes

    def get_ano(self):
        """
        Método de acesso ao campo ano
        :return: o ano
        """
        return self.__ano

    # Método modificador
    def set_data(self, dia, mes, ano):
        """
        Método modificador de uma Data
        :param dia: o novo dia
        :param mes: o novo mês
        :param ano: o novo ano
        """
        if e_valida(dia, mes, ano):
            self.__dia = dia
            self.__mes = mes
            self.__ano = ano

    # Métodos utilitários
    def mais_um_dia(self):
        """
        Incrementa um dia na Data
        """
        ndm = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
        if e_bissexto(self.__ano):
            ndm[2] = 29
        self.__dia += 1
        if self.__dia > ndm[self.__mes]:
            self.__dia = 1
            self.__mes += 1
            if self.__mes > 12:
                self.__mes = 1
                self.__ano += 1

    def num_dias_desde_1900(self):
        """
        Calcula o número de dias desde 01/01/1900
        :return: o número de dias passados
        """
        ndm = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
        if e_bissexto(self.__ano):
            ndm[2] = 29
        num_dias = 0
        for ano in range(1900, self.__ano):
            if e_bissexto(ano):
                num_dias += 366
            else:
                num_dias += 365
        for mes in range(1, self.__mes):
            num_dias += ndm[mes]
        return num_dias + self.__dia - 1

    def dia_da_semana(self):
        """
        Retorna o número do dia da semana (SEG=0, TER=1, ..., DOM=6)
        :return: o índice do dia da semana
        """
        return self.num_dias_desde_1900() % 7

    # Métodos de comparação
    def __eq__(self, other):
        return (self.__ano, self.__mes, self.__dia) == (other.__ano, other.__mes, other.__dia)

    def __ne__(self, other):
        return (self.__ano, self.__mes, self.__dia) != (other.__ano, other.__mes, other.__dia)

    def __lt__(self, other):
        return (self.__ano, self.__mes, self.__dia) < (other.__ano, other.__mes, other.__dia)

    def __le__(self, other):
        return (self.__ano, self.__mes, self.__dia) <= (other.__ano, other.__mes, other.__dia)

    def __gt__(self, other):
        return (self.__ano, self.__mes, self.__dia) > (other.__ano, other.__mes, other.__dia)

    def __ge__(self, other):
        return (self.__ano, self.__mes, self.__dia) >= (other.__ano, other.__mes, other.__dia)

    # Métodos de exibição
    def __str__(self):
        return "{:02d}/{:02d}/{:d}".format(self.__dia, self.__mes, self.__ano)

    def str_extenso(self):
        nds = ("segunda-feira", "terça-feira", "quarta-feira", "quinta-feira",
               "sexta-feira", "sábado", "domingo")
        ndm = ("", "janeiro", "fevereiro", "março", "abril", "maio", "junho",
               "julho", "agosto", "setembro", "outubro", "novembro", "dezembro")
        return "{:d} de {:s} de {:d}, {:s}".format(self.__dia,
                                                   ndm[self.__mes],
                                                   self.__ano,
                                                   nds[self.dia_da_semana()])

def e_bissexto(ano):
    return ano % 4 == 0 and ano % 100 != 0 or ano % 400 == 0

def e_valida(dia, mes, ano):
    ndm = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    if e_bissexto(ano):
        ndm[2] = 29
    if ano < 1900:
        return False
    if mes < 1 or mes > 12:
        return False
    if dia < 1 or dia > ndm[mes]:
        return False
    return True

t = 1
while True:
    v = int(input())
    if v == 0:
        break
    print("Teste", t)
    t += 1
    print(v//50, end=' ')
    v %= 50
    print(v//10, end=' ')
    v %= 10
    print(v//5, v%5, end='\n\n')

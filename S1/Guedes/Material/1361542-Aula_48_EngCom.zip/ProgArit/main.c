#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "matematica.h"

void sleep(time_t delay)
{
    time_t timer0, timer1;
    time(&timer0);
    do
    {
        time(&timer1);
    } while((timer1 - timer0) < delay);
}

int main()
{
    int nt;
    float ti, ra;
    char snum[21];

    while(1) {
        printf("*************************\n");
        printf("* Progress%co Aritm%ctica *\n", 198, 130);
        printf("*************************\n");
        printf("  N%cmero de termos (0 para sair): ",163);
        fflush(stdin);
        gets(snum);
        while(!e_inteiro(snum))
        {
            printf("\n  Favor digite um n%cmero inteiro >= 0: ", 163);
            gets(snum);
        }
        nt = atoi(snum);
        if(nt <= 0)
        {
            printf("\n  * Fim do aplicativo *\n");
            sleep(3);
            break;
        }
        printf("  Termo inicial: ");
        fflush(stdin);
        gets(snum);
        while(!e_real(snum))
        {
            printf("\n  Favor digite um n%cmero >= 0: ", 163);
            gets(snum);
        }
        ti = atof(snum);
        printf("  Raz%co: ", 198);
        fflush(stdin);
        gets(snum);
        while(!e_real(snum))
        {
            printf("\n  Favor digite um n%cmero >= 0: ", 163);
            gets(snum);
        }
        ra = atof(snum);
        printf("\n  ");
        prog_arit(nt, ti, ra);
        printf("\n");
    }
    return 0;
}

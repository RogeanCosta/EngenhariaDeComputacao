import figuras
import time

def catavento(num_pas, tam_pa, esp=1, corL="black", corP="white"):
    for i in range(num_pas):
        figuras.losango_cor(tam_pa, 360/num_pas,esp,corL,corP)
        figuras.tat.left(360/num_pas)


#figuras.tat.speed(0)

figuras.tat.tracer(0,0)

for i in range(720):
    catavento(20, 100, 3)
    figuras.tat.update()
    time.sleep(0.1)
    figuras.tat.clear()
    figuras.tat.left(0.5)
catavento(20, 100, 3)
figuras.tat.update()

import time
import random
import pickle

def menu_principal(lis, ind):
    print("\n"+66*"=")
    print("Ditados Populares".center(66))
    print(66*"="+"\n")
    print(' ', len(lis[ind])*'-')
    print(' ', lis[ind])
    print(' ', len(lis[ind])*'-')
    print("\n  1 - Novo ditado")
    print("  2 - Mostrar próximo ditado")
    print("  3 - Mostrar o ditado anterior")
    print("  4 - Mostrar ditado aleatório")
    print("  5 - Excluir ditado atual")
    print("  ----------------------")
    print("  0 - Sair do Aplicativo\n")
    return input("  Escolha uma opção: ")


def principal():
##    lis_dit =['Para bom entendedor, meia palavra basta',
##              'De grão em grão a galinha enche o papo',
##              'Cada macaco no seu galho']
    arq = open("ditados.arq", "rb")
    lis_dit = pickle.load(arq)
    arq.close()
    atual = random.randint(0, len(lis_dit)-1)
    while True:
        op = menu_principal(lis_dit, atual)
        if op == '0':
            arq = open("ditados.arq", "wb")
            pickle.dump(lis_dit, arq)
            arq.close()
            print("\n  ** Fim do aplicativo **")
            time.sleep(3)
            break
        elif op == '1':
            print(66*"-")
            print("{:s}".format("NOVO DITADO".center(66)))
            print(66*"-")
            dit = input("\n  Digite o ditado: ")
            lis_dit.append(dit)
        elif op == '2':
            atual = (atual + 1) % len(lis_dit)
##            atual += 1
##            if atual == len(lis_dit):
##                atual = 0
        elif op == '3':
            atual -= 1
            if atual < 0:
                atual = len(lis_dit) - 1
        elif op == '4':
            atual = random.randint(0, len(lis_dit)-1)
        elif op == '5':
            print(66*"-")
            print("{:s}".format("Deseja apagar".center(66)))
            print("{:s}".format(lis_dit[atual].center(66)))
            print(66*"-")
            res = input("\n  Responda (S/N): ")
            while res.upper() != 'S' and res.upper() != 'N':
                res = input("\n  Responda exclusivamente (S ou N): ")
            if res.upper() == 'S':
                lis_dit.pop(atual)
                atual -= 1
                if atual < 0:
                    atual = len(lis_dit)-1
        else:
            print("\n  * ENTRADA INVÁLIDA *\n")

principal()

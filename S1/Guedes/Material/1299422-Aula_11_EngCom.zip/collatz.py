def seq_collatz(n):
    while n != 1:
        print(n, end=' ')
        if n % 2 == 0:
            n = n // 2
        else:
            n = 3 * n + 1
    print(n)

def vida_collatz(n):
    res = 1
    while n != 1:
        res += 1
        if n % 2 == 0:
            n = n // 2
        else:
            n = 3 * n + 1
    return res

maior = -1000
ini = int(input())
fim = int(input())
for i in range(ini, fim+1):
    v = vida_collatz(i)
    if v > maior:
        maior = v
    #seq_collatz(i)
    #print(vida_collatz(i))
print(ini, fim, maior)






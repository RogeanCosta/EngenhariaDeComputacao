import matematica
import time

while True:
    try:
        print("************************")
        print("* Título do aplicativo *")
        print("************************")

        entrada = input("  Digite um inteiro >= 0 (negativo para sair): ")
        num = int(entrada)

        if num < 0:
            print("\n  FIM  DO APLICATIVO\n\n")
            time.sleep(3)
            break

        print("\n  Saída do aplicativo")
        print("\n")
    except ValueError:
        print("\n  *** Favor digitar um número inteiro ***\n\n")


        

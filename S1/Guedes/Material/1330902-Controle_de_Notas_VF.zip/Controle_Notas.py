import data
import aluno
import time
import pickle

def menu_principal():
    print("\n"+66*"=")
    print("Controle de Notas".center(66))
    print(66*"="+"\n")
    print("  1 - Listar alunos")
    print("  2 - Matricular aluno")
    print("  3 - Buscar Aluno pelo nome")
    print("  4 - Alterar dados")
    print("  5 - Trancar matrícula")
    print("  6 - Reabrir matrícula")
    print("  ----------------------")
    print("  0 - Sair do Aplicativo\n")
    return input("  Escolha uma opção: ")


def menu_listagem():
    print("\n"+66*"=")
    print("Mostra lista de alunos".center(66))
    print(66*"="+"\n")
    print("  1 - Ordenada pelo código")
    print("  2 - Ordenada pelo nome")
    print("  3 - Ordenada pelo idade")
    print("  4 - Ordenada pelo média")
    print("  5 - Lista de alunos trancados")
    print("  ----------------------------")
    print("  0 - Voltar ao menu principal\n")
    return input("  Escolha uma opção: ")

def menu_altera():
    print("\n"+66*"=")
    print("Alteração de dados".center(66))
    print(66*"="+"\n")
    print("  1 - Alterar nome")
    print("  2 - Alterar data de nascimento")
    print("  3 - Alterar nota primeira etapa")
    print("  4 - Alterar nota segunda etapa")
    print("  ----------------------------")
    print("  0 - Voltar ao menu principal\n")
    return input("  Escolha uma opção: ")


def mostre_lista_de_alunos(la):
    print(66*"-")
    print("Código {:30s} Nascimento   AP1   AP2 Média".format("Nome"))
    print("------", 30*"-", 10*'-', 5*"-", 5*"-", 5*"-")
    for alu in la:
        print(alu)
    print(66*"-")
    
def str_lista_de_alunos(la):
    res = 66*"-" + "\nCódigo {:30s} Nascimento   AP1   AP2 Média\n".format("Nome")
    res += "------ " + 30*"-" + " " + 10*"-" + " " + 5*"-" + " " + 5*"-" + " " + 5*"-"
    for alu in la:
        res += "\n" + str(alu)
    res += "\n" + 66*"-" + "\n"
    return res

def buscar_pelo_nome(lis):
    letras_ini = input("  Digite as letras iniciais do nome: ")
    for alu in sorted(lis, key=lambda alu : alu.get_nome()):
        if alu.get_nome().startswith(letras_ini):
            print("  {:06d} {:30s} {:s}".format(alu.get_codigo(),
                                            alu.get_nome()[:30],
                                            str(alu.get_nasc())))

def buscar_pelo_codigo(cod, lis):
    for i in range(len(lis)):
        if lis[i].get_codigo() == cod:
            return i
    return -1

def busca_binaria(cod, lis):
    ini = 0
    fim = len(lis)-1
    while ini <= fim:
        mei = (ini + fim) // 2
        if cod == lis[mei].get_codigo():
            return mei
        elif cod > lis[mei].get_codigo():
            ini = mei + 1
        else:
            fim = mei - 1
    return -1
            
def salva_txt(lis):
    res = input("  Deseja salvar a lista como arquivo txt? (S/N): ")
    if res.upper() == 'S':
        arq_nom = input("  Nome do arquivo (nome.txt): ")
        if not arq_nom.endswith(".txt"):
            arq_nom += ".txt"
        arq = open(arq_nom, "w")
        arq.write(str_lista_de_alunos(lis))
        arq.close()

def principal():
##    lis_alu = []
##    for i in range(1, 21):
##        lis_alu.append(massa_teste.gere_aluno(i))
    lis_alu = []
    lis_trancados = []
    ult_cod = 0
    alterado = False
    try:
        arq = open("alunos.arq", "rb")
        ult_cod = pickle.load(arq)
        lis_alu = pickle.load(arq)
        arq.close()
    except FileNotFoundError:
        arq = open("alunos.arq", "wb")
        pickle.dump(ult_cod, arq)
        pickle.dump(lis_alu, arq)
        arq.close()

    try:
        arq_tranc = open("trancados.arq", "rb")
        lis_trancados = pickle.load(arq_tranc)
        arq_tranc.close()
    except FileNotFoundError:
        arq_tranc = open("trancados.arq", "wb")
        pickle.dump(lis_trancados, arq_tranc)
        arq_tranc.close()
        
    while True:
        op = menu_principal()
        if op == '0':
            if alterado:
                res = input("  Dados alterados. Deseja salvar? (S/N): ")
                while res != 'S' and res != 's' and res != 'N' and res != 'n':
                    res = input("  Favor responder S ou N: ")
                if res ==  'S' or res == 's':
                    arq = open("alunos.arq", "wb")
                    pickle.dump(ult_cod, arq)
                    pickle.dump(lis_alu, arq)
                    arq.close()
                    arq_tranc = open("trancados.arq", "wb")
                    pickle.dump(lis_trancados, arq_tranc)
                    arq_tranc.close()

                    print("  Dados salvo")
                else:
                    print("  Alterações descartadas")
            print("\n  ** Fim do aplicativo **")
            time.sleep(3)
            break
        elif op == '1':
            while True:
                op2 = menu_listagem()
                if op2 == '0':
                    break
                elif op2 == '1':
                    print(66*"-")
                    print("{:s}".format("LISTA DE ALUNOS ORDENADOS PELO CÓDIGO".center(66)))
                    mostre_lista_de_alunos(lis_alu)
                    salva_txt(lis_alu)
                elif op2 == '2':
                    print(66*"-")
                    print("{:s}".format("LISTA DE ALUNOS ORDENADOS PELO NOME".center(66)))
                    print(str_lista_de_alunos(sorted(lis_alu, key=lambda alu : alu.get_nome())))
                    salva_txt(sorted(lis_alu, key=lambda alu : alu.get_nome()))
                elif op2 == '3':
                    print(66*"-")
                    print("{:s}".format("LISTA DE ALUNOS ORDENADOS PELA IDADE".center(66)))
                    mostre_lista_de_alunos(sorted(lis_alu, key=lambda x : x.get_nasc()))
                    salva_txt(sorted(lis_alu, key=lambda alu : alu.get_nasc()))
                elif op2 == '4':
                    print(66*"-")
                    print("{:s}".format("LISTA DE ALUNOS ORDENADOS PELA MÉDIA".center(66)))
                    mostre_lista_de_alunos(sorted(lis_alu, key=lambda x : x.media(), reverse=True))
                    salva_txt(sorted(lis_alu, key=lambda alu : alu.media(), reverse=True))
                elif op2 == '5':
                    print(66*"-")
                    print("{:s}".format("LISTA DE ALUNOS COM MATRÍCULA TRANCADA".center(66)))
                    mostre_lista_de_alunos(sorted(lis_trancados))
                    salva_txt(sorted(lis_trancados))
                else:
                    print("\n  * ENTRADA INVÁLIDA *\n")
        elif op == '2':
            print(66*"-")
            print("{:s}".format("MATRICULAR ALUNO".center(66)))
            print(66*"-")
            nome = input("  Nome: ")
            d, m, a = map(int, input("  Data de nascimento (dd/mm/aaaa): ").split(sep='/'))
            while not data.e_valida(d, m, a):
                print("  Data inválida. Favor redigite.")
                d, m, a = map(int, input("  Data de nascimento (dd/mm/aaaa): ").split(sep='/'))
            res = input("  Deseja salvar {:06d} {:s} {:02d}/{:02d}/{:d}".format(
                ult_cod+1, nome, d, m, a) + "(S/N): ")
            while res != 'S' and res != 's' and res != 'N' and res != 'n':
                res = input("  Favor responder S ou N: ")
            if res == 'S' or res == 's':
                lis_alu.append(aluno.Aluno(ult_cod+1, nome, data.Data(d,m,a)))
                ult_cod += 1
                alterado = True
                print("  Matrícula realizada")
            else:
                print("  Matrícula não realizada")
            
        elif op == '3':
            print(66*"-")
            print("{:s}".format("BUSCAR ALUNO PELO NOME".center(66)))
            print(66*"-")
            buscar_pelo_nome(lis_alu)
        elif op == '4':
            print(66*"-")
            print("{:s}".format("ALTERAR DADOS".center(66)))
            print(66*"-")
            cod = int(input("  Código do aluno: "))
            ind = busca_binaria(cod, lis_alu)
            print(30*"-")
            if ind < 0:
                print("  Código inexistente")
                continue
            while True:
                op2 = menu_altera()
                if op2 == '0':
                    break
                if op2 == '1':
                    print("  Nome atual:", lis_alu[ind].get_nome())
                    nn = input("  Novo nome: ")
                    lis_alu[ind].set_nome(nn)
                    alterado = True
                elif op2 == '2':
                    print("  Data de nascimento atual:", lis_alu[ind].get_nasc())
                    nd, nm, na = map(int, input("  Nova data de nascimento (dd/mm/aaaa): ").split(sep='/'))
                    if data.e_valida(nd, nm, na):
                        lis_alu[ind].set_nasc(data.Data(nd, nm, na))
                        alterado = True
                elif op2 == '3':
                    if lis_alu[ind].get_ap1() > 10.5:
                        print("  Nota de AP1 atual: SEM NOTA")
                    else:
                        print("  Nota de AP1 atual: {:4.1f}".format(lis_alu[ind].get_ap1()))
                    nn1 = float(input("  Nova nota de AP1: "))
                    if 0.0 <= nn1 <= 10.0:
                        lis_alu[ind].set_ap1(nn1)
                        alterado = True
                        print("  Nota de AP1 alterada")
                    else:
                        print("  Nota inválida (não alterada)")
                elif op2 == '4':
                    if lis_alu[ind].get_ap2() > 10.5:
                        print("  Nota de AP2 atual: SEM NOTA")
                    else:
                        print("  Nota de AP2 atual: {:4.1f}".format(lis_alu[ind].get_ap2()))
                    nn2 = float(input("  Nova nota de AP2: "))
                    if 0.0 <= nn2 <= 10.0:
                        lis_alu[ind].set_ap2(nn2)
                        alterado = True
                        print("  Nota de AP2 alterada")
                    else:
                        print("  Nota inválida (não alterada)")
                else:
                    print("\n  * ENTRADA INVÁLIDA *\n")
        elif op == '5':
            print(66*"-")
            print("{:s}".format("TRANCAR MATRÍCULA".center(66)))
            print(66*"-")
            cod = int(input("  Código do aluno: "))
            ind = busca_binaria(cod, lis_alu)
            if ind < 0:
                print("  Código inexistente")
                continue
            print(30*"-")
            alu = lis_alu[ind]
            lis_alu.remove(alu)
            lis_trancados.append(alu)
            lis_trancados = sorted(lis_trancados)
            #lis_trancados.append(lis_alu.pop(ind))

            alterado = True
        elif op == '6':
            print(66*"-")
            print("{:s}".format("REABRIR MATRÍCULA".center(66)))
            print(66*"-")
            cod = int(input("  Código do aluno: "))
            ind = busca_binaria(cod, lis_trancados)
            print(30*"-")
            if ind < 0:
                print("  Código não encontrado")
                continue
            lis_alu.append(lis_trancados.pop(ind))
            lis_alu = sorted(lis_alu)

            alterado = True
        else:
            print("\n  * ENTRADA INVÁLIDA *\n")

principal()

import turtle as tat

def quadrado(tam_lado):
    """Desenha um quadrado especificado o tam_lado"""
    for i in range(4):
        tat.forward(tam_lado)
        tat.left(90)

def quadrado_cor(tam_lado, esp=1, corL="black", corP="white"):
    tat.pensize(esp)
    tat.color(corL, corP)
    tat.begin_fill()
    quadrado(tam_lado)
    tat.end_fill()
    
def triang_equi(tam_lado):
    for i in range(3):
        tat.forward(tam_lado)
        tat.left(120)

def triang_equi_cor(tam_lado, esp=1, corL="black", corP="white"):
    tat.pensize(esp)
    tat.color(corL, corP)
    tat.begin_fill()
    triang_equi(tam_lado)
    tat.end_fill()


def poli_reg(num_lados, tam_lado):
    for i in range(num_lados):
        tat.forward(tam_lado)
        tat.left(360 / num_lados)

def poli_reg_cor(num_lados, tam_lado, esp=1, corL="black", corP="white"):
    tat.pensize(esp)
    tat.color(corL, corP)
    tat.begin_fill()
    poli_reg(num_lados, tam_lado)
    tat.end_fill()

def losango(tam_lado, ang):
    for i in range(2):
        tat.forward(tam_lado)
        tat.left(ang)
        tat.forward(tam_lado)
        tat.left(180-ang)

def losango_cor(tam_lado, ang, esp=1, corL="black", corP="white"):
    tat.pensize(esp)
    tat.color(corL, corP)
    tat.begin_fill()
    losango(tam_lado, ang)
    tat.end_fill()








    

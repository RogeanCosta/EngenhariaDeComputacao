import turtle as tat

def quad_arredondado(tl, ra):
    tat.penup()
    tat.forward(ra)
    tat.pendown()
    for i in range(4):
        tat.forward(tl - 2*ra)
        tat.circle(ra, 90)
    tat.penup()
    tat.backward(ra)
    tat.pendown()

quad_arredondado(200, 0)

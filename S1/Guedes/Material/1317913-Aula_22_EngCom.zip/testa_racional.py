import racional
import random


for i in range(5):
    a = racional.Racional(random.randint(-5,5),random.randint(-5,5))
    b = racional.Racional(random.randint(-5,5),random.randint(-5,5))
    s = a+b
    a.simplifica()
    b.simplifica()
    s.simplifica()
    print(a, "+", b, "=", s)
    

##lis_ra = []
##for i in range(10):
##    lis_ra.append(racional.Racional(random.randint(-5,5), random.randint(-5,5)))
##
##for i in lis_ra:
##    print(i, end='  ')
##print("\n-----------------------")
##for i in lis_ra:
##    i.simplifica()
##    print(i, end='  ')

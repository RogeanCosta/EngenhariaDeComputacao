#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void preenche_matriz(int nl, int nc, int mat[nl][nc])
{
    int i, j;
    for(i=0; i<nl; i++)
    {
        for(j=0; j<nc; j++)
        {
            mat[i][j] = rand()%100;
        }
    }
}

void mostre_matriz(int nl, int nc, int mat[nl][nc])
{
    int i, j;
    for(i=0; i<nl; i++)
    {
        for(j=0; j<nc; j++)
        {
            printf("%3d", mat[i][j]);
        }
        printf("\n");
    }
}

void mostre_matriz2(int nl, int nc, int mat[nl][nc])
{
    int i, *p = &mat[0][0];
    for(i=0; i<nl*nc; i++) {
        if(i%nc == 0)
            printf("\n");
        printf("%3d", *p);
        p++;
    }
}

int main()
{
    srand(time(NULL));
    int matriz[100][100];
    int nl = 10, nc = 15;
    preenche_matriz(nl, nc, matriz);
    mostre_matriz(nl, nc, matriz);
    printf("\n");
    mostre_matriz2(nl, nc, matriz);
    return 0;
}

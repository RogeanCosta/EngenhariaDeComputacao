import data
import aluno
import time
import massa_teste
import pickle

def menu_principal():
    print("\n"+66*"=")
    print("Controle de Notas".center(66))
    print(66*"="+"\n")
    print("  1 - Listar alunos")
    print("  2 - Matricular aluno")
    print("  3 - Buscar Aluno")
    print("  4 - Alterar dados")
    print("  ----------------------")
    print("  0 - Sair do Aplicativo\n")
    return input("  Escolha uma opção: ")


def menu_listagem():
    print("\n"+66*"=")
    print("Mostra lista de alunos".center(66))
    print(66*"="+"\n")
    print("  1 - Ordenada pelo código")
    print("  2 - Ordenada pelo nome")
    print("  3 - Ordenada pelo idade")
    print("  4 - Ordenada pelo média")
    print("  ----------------------------")
    print("  0 - Voltar ao menu principal\n")
    return input("  Escolha uma opção: ")

def menu_altera():
    print("\n"+66*"=")
    print("Alteração de dados".center(66))
    print(66*"="+"\n")
    print("  1 - Alterar nome")
    print("  2 - Alterar data de nascimento")
    print("  3 - Alterar nota primeira etapa")
    print("  4 - Alterar nota segunda etapa")
    print("  ----------------------------")
    print("  0 - Voltar ao menu principal\n")
    return input("  Escolha uma opção: ")


def mostre_lista_de_alunos(la):
    print(66*"-")
    print("Código {:30s} Nascimento   AP1   AP2 Média".format("Nome"))
    print("------", 30*"-", 10*'-', 5*"-", 5*"-", 5*"-")
    for alu in la:
        print(alu)
    
def str_lista_de_alunos(la):
    res = 66*"-" + "\nCódigo {:30s} Nascimento   AP1   AP2 Média\n".format("Nome")
    res += "------ " + 30*"-" + " " + 10*"-" + " " + 5*"-" + " " + 5*"-" + " " + 5*"-"
    for alu in la:
        res += "\n" + str(alu)
    return res

def buscar_pelo_nome(lis):
    letras_ini = input("  Digite as letras iniciais do nome: ")
    for alu in sorted(lis, key=lambda alu : alu.get_nome()):
        if alu.get_nome().startswith(letras_ini):
            print("  {:06d} {:30s} {:s}".format(alu.get_codigo(),
                                            alu.get_nome()[:30],
                                            str(alu.get_nasc())))

def buscar_pelo_codigo(cod, lis):
    for i in range(len(lis)):
        if lis[i].get_codigo() == cod:
            return i
    return -1

def principal():
##    lis_alu = []
##    for i in range(1, 21):
##        lis_alu.append(massa_teste.gere_aluno(i))
    arq = open("alunos.arq", "rb")
    ult_cod = pickle.load(arq)
    lis_alu = pickle.load(arq)
    arq.close()
    while True:
        op = menu_principal()
        if op == '0':
            arq = open("alunos.arq", "wb")
            pickle.dump(ult_cod, arq)
            pickle.dump(lis_alu, arq)
            arq.close()
            print("\n  ** Fim do aplicativo **")
            time.sleep(3)
            break
        elif op == '1':
            while True:
                op2 = menu_listagem()
                if op2 == '0':
                    break
                elif op2 == '1':
                    print(66*"-")
                    print("{:s}".format("LISTA DE ALUNOS ORDENADOS PELO CÓDIGO".center(66)))
                    mostre_lista_de_alunos(lis_alu)
                elif op2 == '2':
                    print(66*"-")
                    print("{:s}".format("LISTA DE ALUNOS ORDENADOS PELO NOME".center(66)))
                    #mostre_lista_de_alunos(lis_alu)
                    print(str_lista_de_alunos(sorted(lis_alu, key=lambda alu : alu.get_nome())))
                elif op2 == '3':
                    print(66*"-")
                    print("{:s}".format("LISTA DE ALUNOS ORDENADOS PELA IDADE".center(66)))
                    mostre_lista_de_alunos(sorted(lis_alu, key=lambda x : x.get_nasc()))
                elif op2 == '4':
                    print(66*"-")
                    print("{:s}".format("LISTA DE ALUNOS ORDENADOS PELA MÉDIA".center(66)))
                    mostre_lista_de_alunos(sorted(lis_alu, key=lambda x : x.media(), reverse=True))
                else:
                    print("\n  * ENTRADA INVÁLIDA *\n")
        elif op == '2':
            print(66*"-")
            print("{:s}".format("MATRICULAR ALUNO".center(66)))
            print(66*"-")
            nome = input("  Nome: ")
            d, m, a = map(int, input("  Data de nascimento (dd/mm/aaaa): ").split(sep='/'))
            while not data.e_valida(d, m, a):
                print("  Data inválida. Favor redigite.")
                d, m, a = map(int, input("  Data de nascimento (dd/mm/aaaa): ").split(sep='/'))
            res = input("  Deseja salvar {:06d} {:s} {:02d}/{:02d}/{:d}".format(
                ult_cod+1, nome, d, m, a) + "(S/N): ")
            while res != 'S' and res != 's' and res != 'N' and res != 'n':
                res = input("  Favor responder S ou N: ")
            if res == 'S' or res == 's':
                lis_alu.append(aluno.Aluno(ult_cod+1, nome, data.Data(d,m,a)))
                ult_cod += 1
                print("  Matrícula realizada")
            else:
                print("  Matrícula não realizada")
            
        elif op == '3':
            print(66*"-")
            print("{:s}".format("BUSCAR ALUNO PELO NOME".center(66)))
            print(66*"-")
            buscar_pelo_nome(lis_alu)
        elif op == '4':
            print(66*"-")
            print("{:s}".format("ALTERAR DADOS".center(66)))
            print(66*"-")
            while True:
                op2 = menu_altera()
                if op2 == '0':
                    break
                cod = int(input("  Código do aluno: "))
                ind = buscar_pelo_codigo(cod, lis_alu)
                if op2 == '1':
                    print("  Nome atual:", lis_alu[ind].get_nome())
                    nn = input("  Novo nome: ")
                    lis_alu[ind].set_nome(nn)
            
        else:
            print("\n  * ENTRADA INVÁLIDA *\n")

principal()

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


void extenso(int num, char ext[])
{
    if(num == 100) {
        strcpy(ext, "cem");
        return;
    }
    int c, d, u;

    char uni[][11] = {"","um","dois","tr\x88s","quatro",
                      "cinco","seis","sete","oito","nove"};
    char dez[][16] = {"","dez","vinte","trinta","quarenta",
                      "cinquenta","sessenta","setenta",
                      "oitenta","noventa"};
    char cen[][16] = {"","cento","duzentos","trezentos",
                      "quatrocentos","quinhentos","seiscento",
                      "setecentos","oitocentos","novecentos"};
    char esp[][16] = {"","onze","doze","treze","quatorze",
                      "quinze","dezesseis","dezessete",
                      "dezoito","dezenove"};

    c = num / 100;
    d = num % 100 / 10;
    u = num % 10;

    strcpy(ext, "");

    if(c > 0)
    {
        strcat(ext, cen[c]);
        if(d > 0 || u > 0)
            strcat(ext, " e ");
    }

    if(d == 1 && u > 0)
    {
        strcat(ext, esp[u]);
        return;
    }

    if(d > 0)
    {
        strcat(ext, dez[d]);
        if(u > 0)
            strcat(ext, " e ");
    }

    if(u > 0)
        strcat(ext, uni[u]);
 }

int main()
{
    int i, maior = 0;
    char por_ext[35];
    for(i=1; i<1000; i++) {
        extenso(i, por_ext);
        if(strlen(por_ext) > maior)
            maior = strlen(por_ext);
        puts(por_ext);
    }
    printf("%d\n", maior);

    return 0;
}

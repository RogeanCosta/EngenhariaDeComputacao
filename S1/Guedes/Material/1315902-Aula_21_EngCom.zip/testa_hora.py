from hora import *
import random
#import hora

lista_horas = []
for i in range(15):
    lista_horas.append(Hora(random.randint(0,23),random.randint(0,59),random.randint(0,59)))

for h in lista_horas:
    print(h)
print("---------------------------")
for h in sorted(lista_horas):
    print(h)

print("---------------------------")
for h in sorted(lista_horas, reverse=True):
    print(h)


##h1 = Hora(25,59,50)
##h2 = Hora(12,59,50)



##for i in range(61):
##    print(h2, h2.str_12())
##    h2.mais_um_segundo()

#print(h1 < h2)

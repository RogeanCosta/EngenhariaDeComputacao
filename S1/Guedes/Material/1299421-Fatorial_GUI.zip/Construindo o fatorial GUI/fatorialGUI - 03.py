""" INSERINDO UM CAMPO DE TEXTO (Entry)"""

import tkinter as tk
from tkinter import ttk

win = tk.Tk()
win.title("Fatorial - IFCE")

rot1 = ttk.Label(win, text=" O fatorial de ")
rot1.grid(column=0, row=0, padx=5, pady=5)

entrada = tk.StringVar()                              # <--
ent = ttk.Entry(win, width=6, textvariable=entrada)   # <--
ent.grid(column=1, row=0, padx=5, pady=5)             # <--
ent.focus()                                           # <--

win.mainloop()


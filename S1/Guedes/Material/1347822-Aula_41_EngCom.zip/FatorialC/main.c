#include <stdio.h>
#include <stdlib.h>
#include "matematica.h"

int main()
{
    int num, i;
//    for(i=0; i<256; i++)
//        printf("%c %3d %x\n", i, i, i);
//    return 0;

    while(1)
    {
        printf("***********************\n");
        printf("* C%clculo do Fatorial *\n", 160);
        printf("***********************\n");
        printf("  Digite um inteiro >= 0 (negativo para sair): ");
        scanf("%d", &num);
        if(num < 0)
        {
            printf("\n  FIM  DO APLICATIVO\n\n");
            break;
        }
        if(num > 20)
        {
            printf("\n  Valor fora da faixa [0,20]\n\n");
            continue;
        }

        printf("\n  %d! = ", num);
        if(num > 1 && num <= 10)
        {
            for(i=num; i>1; i--)
                printf("%d x ", i);
            printf("1 = ");
        }
        printf("%I64u\n\n", fatorial(num));
    }

    return 0;
}

import turtle

def fern(t):
    if t < 5:
        return
    turtle.forward(t/20)
    turtle.left (80)
    fern(0.3*t)
    turtle.right (82)
    turtle.forward (t/20)
    turtle.right (80)
    fern(0.3*t)
    turtle.left (78)
    fern(0.9*t)
    turtle.left (2)
    turtle.backward(t/20)
    turtle.left (2)
    turtle.backward(t/20)

turtle.speed (0)
turtle.left(90)
turtle.colormode(255)
tela = turtle.getscreen ()
tela.bgcolor (150,255,150)
turtle.color ((0,100,0),(0,100,0))
turtle.penup()
turtle.backward(260)
turtle.pendown ()
turtle.pensize (1.5)
turtle.hideturtle ()
turtle.tracer (10)
fern(700)
turtle.done()

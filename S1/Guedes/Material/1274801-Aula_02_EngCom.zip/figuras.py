import turtle as tat

def quadrado(tam_lado):
    for i in range(4):
        tat.forward(tam_lado)
        tat.left(90)

def triang_equi(tam_lado):
    for i in range(3):
        tat.forward(tam_lado)
        tat.left(120)

def poli_reg(num_lados, tam_lado):
    for i in range(num_lados):
        tat.forward(tam_lado)
        tat.left(360 / num_lados)




tat.speed(0)
for i in range(3, 21):
    poli_reg(i, 40)

    

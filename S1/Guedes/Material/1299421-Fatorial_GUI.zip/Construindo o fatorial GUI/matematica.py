import math

def prog_arit(nt, ti, ra):
    """ Mostra os nt primeiros termos de uma progressão aritimética dados o termo inicial (ti) e a razão (ra)"""
    for i in range(nt-1):
        print(ti, end=', ')
        ti = ti + ra
    print(ti)

def prog_geom(nt, ti, ra):
    """ Mostra os nt primeiros termos de uma progressão geométrica dados o termo inicial (ti) e a razão (ra)"""
    for i in range(nt-1):
        print(ti, end=', ')
        ti = ti * ra
    print(ti)

def quad_perf(n):
    """ Mostra os n primeiros quadrados perfeitos iniciando em 1"""
    for i in range(1, n):
        print(i**2, end=', ')
    print(n**2)

def quad_perf2(n):
    """ Mostra os n primeiros quadrados perfeitos iniciando em 1"""
    ra = 3
    ti = 1
    for i in range(n-1):
        print(ti, end=', ')
        ti = ti + ra
        ra = ra + 2
    print(ti)
    
def multiplica(a, b):
    """Retorna o valor de a vezes b"""
    res = 0
    for i in range(a):
        res = res + b
    return res

def expo(a, n):
    """Retorna a elevado a n"""
    res = 1
    for i in range(n):
        res = multiplica(res, a)
    return res

def fatorial(n):
    """Retorna o fatorial de n"""
    res = 1
    for i in range(2, n+1):
        res = res * i
    return res

def fibo(n):
    """Mostra os n primeiros termos da sequência de Fibonacci"""
    p = 1
    s = 1
    print(p,s, sep=', ', end=', ')
    for i in range(n-3):
        print(p+s, end=', ')
        p, s = s, p+s
    print(p+s)


def mostre_divisores(num):
    """Mostra os divisores de num"""
    for i in range(1, num//2 + 1):
        if num % i == 0:
            print(i, end=', ')
    print(num)

def conte_divisores(num):
    """Retorna o número de divisores de num"""
    res = 0
    for i in range(1, num//2 + 1):
        if num % i == 0:
            res = res + 1
    return res + 1


def é_primo(num):
    """Retorna True se num for primo e False se não for"""
    if conte_divisores(num) == 2:
        return True
    else:
        return False

def é_primo2(num):
    """Retorna True se num for primo e False se não for"""
    if num == 1:
        return False
    for i in range(2, num//2+1):
        if num%i == 0:
            return False
    return True
    
def mostre_primos(ini, fim):
    """Mostra os primos no intervalo fechado [ini, fim]"""
    for i in range(ini,fim+1):
        if é_primo2(i):
            print(i,end=' ')

def raizes_eq_2_grau(a, b, c):
    """Mostra as raízes de uma equação de grau 2"""
    d = b**2 - 4*a*c
    if d < 0:
        rd = math.sqrt(abs(d))
        r1 = (complex(-b,rd))/(2*a)
        r1 = complex(round(r1.real,3), round(r1.imag,3))
        r2 = (complex(-b,-rd))/(2*a)
        r2 = complex(round(r2.real,3), round(r2.imag,3))
        print("Duas raízes complexas:",r1,"e",r2)
    elif d == 0:
        print("Duas raízes reais e iguais:",round((-b)/(2*a),3),
              "e",round((-b)/(2*a),3))
    else:
        print("Duas raízes reais e distintas:",round((-b-math.sqrt(d))/(2*a),3),
              "e",round((-b+math.sqrt(d))/(2*a),3))

def mostre_eq(a,b,c):
    """Exibe a equação de 2º grau dados os seus coeficientes"""
    if a > 0: print(a," x",chr(178), sep="", end="")
    if b < 0:
        print(" - ", abs(b), " x", sep="", end="")
    elif b > 0:
        print(" + ", b, " x", sep="", end="")
    if c < 0:
        print(" - ", abs(c), sep="", end="")
    elif c > 0:
        print(" + ", c, sep="", end="")
    
def mdc(a, b):
    """Calcula e retorna o Máximo Divisor Comum de a e b"""
    while a != b:
        if a > b:
            a = a - b
        else:
            b = b - a
    return a

def mdc_aprimorado(a, b):
    while b != 0:
        a, b = b, a%b
    return a


def mmc(a, b):
    """Calcula e retorna o Mínimo Múltiplo Comum de a e b"""
    x = a
    y = b
    while a != b:
        if a > b:
            b = b + y
        else:
            a = a + x
    return a
            
def sep_milhar(num):
    """Recebe um número(num) inteiro e retorna uma string com num por extenso"""
    snum = str(num)
    res = ''
    while len(snum) > 3:
        res = "." + snum[-3:] + res
        snum = snum[:-3]
    return snum + res
























import tkinter as tk

win = tk.Tk()

win.mainloop()


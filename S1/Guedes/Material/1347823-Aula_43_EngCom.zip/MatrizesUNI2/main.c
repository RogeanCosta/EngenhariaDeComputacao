#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void preenche_vetor(int ne, int vet[ne])
{
    int i;
    for(i=0; i<ne; i++)
        vet[i] = rand()%100;
}

void mostre_vetor(int ne, int vet[ne])
{
    int i;
    printf("{");
    for(i=0; i<ne-1; i++)
        printf("%d, ", vet[i]);
    if(ne > 0)
        printf("%d}\n", vet[i]);
    else
        printf("}\n");
}

int soma_vetor(int ne, int vet[ne])
{
    int i, res = 0;
    for(i=0; i<ne; i++)
        res += vet[i];
    return res;
}

float media_vetor(int ne, int vet[ne])
{
    return 1.0 * soma_vetor(ne, vet) / ne;
}

int cmp_int(const void *a, const void *b)
{
    int *va = (int *) a;
    int *vb = (int *) b;
    return *va - *vb;
}

int ind_menor(int ne, int vet[ne])
{
    int i, im=0;
    for(i=1; i<ne; i++)
        if(vet[i] < vet[im])
            im = i;
    return im;
}

int ind_maior(int ne, int vet[ne])
{
    int i, im=0;
    for(i=1; i<ne; i++)
        if(vet[i] > vet[im])
            im = i;
    return im;
}

int busca_valor(int ne, int vet[ne], int val)
{
    int i;
    for(i=0; i<ne; i++)
        if(val == vet[i])
            return i;
    return -1;
}

void insere_no_fim(int *ne, int vet[*ne], int val)
{
    vet[*ne] = val;
    (*ne)++;
}

int main()
{
    srand(time(NULL));
    int vetor_int[20];
    int im, val, rb, ne = 10;
    preenche_vetor(ne, vetor_int);
    mostre_vetor(ne, vetor_int);
    if(ne > 0) {
        printf("  Soma  = %d\n", soma_vetor(ne, vetor_int));
        printf("  M%cdia = %.1f\n", 130, media_vetor(ne, vetor_int));
        im = ind_menor(ne, vetor_int);
        printf("  O menor valor %c %d e est%c na %d%c posi%c%co\n", 130,
                vetor_int[im], 160, im+1, 166, 135, 198);
        im = ind_maior(ne, vetor_int);
        printf("  O maior valor %c %d e est%c na %d%c posi%c%co\n", 130,
                vetor_int[im], 160, im+1, 166, 135, 198);
    }
    printf("  Digite o valor a ser buscado: ");
    scanf("%d", &val);
    rb = busca_valor(ne, vetor_int, val);
    if(rb < 0)
        printf("  %d n%co encontrado\n", val, 198);
    else
        printf("  %d encontrado na %d%c posi%c%co\n", val, rb+1, 166, 135, 198);
    printf("  Digite o valor para ser inserido no final: ");
    scanf("%d", &val);
    insere_no_fim(&ne, vetor_int, val);
    printf("\n");
    mostre_vetor(ne, vetor_int);
    printf("\n  Ordenando o vetor:");
    qsort(vetor_int, ne, sizeof(int), cmp_int);
    printf("\n\n");
    mostre_vetor(ne, vetor_int);
    printf("\n");
    system("pause");
    return 0;
}

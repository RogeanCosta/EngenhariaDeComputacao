#include <stdio.h>

void mostre_tab(int m, int n, char mat[m][n])
{
    int i, j;
    for(i=0; i<m; i++)
    {
        for(j=0; j<n; j++)
            printf("%c ", mat[i][j]);
        printf("\n");
    }
}

int conte_bombas(int m, int n, char mat[m][n], int nl, int nc)
{
    int cl, fl, cc, fc, i, j, res=0;
    cl = (nl == 0 ? 0 : nl-1);
    fl = (nl == m-1 ? nl : nl+1);
    cc = (nc == 0 ? 0 : nc-1);
    fc = (nc == n-1 ? nc : nc+1);
    for(i=cl; i<=fl; i++)
    {
        for(j=cc; j<=fc; j++)
        {
            if(mat[i][j] == '*')
                res++;
        }
    }
    return res;
}

int main()
{
    int i, j, m, n;
    char tab[100][100];
    char lin[101];
    scanf("%d %d", &m, &n);
    for(i=0; i<m; i++)
    {
        gets(lin);
        for(j=0; lin[j]; j++)
            tab[i][j] = lin[j];
    }
    mostre_tab(m, n, tab);
    gets(lin);
//    for(i=0; i<m; i++) {
//        for(j=0; j<n; j++)
//        {
//            if(tab[i][j] == '*')
//                printf("* ");
//            else
//                printf("%d ", conte_bombas(m, n, tab, i, j));
//        }
//        printf("\n");
//    }
//    //printf("%d\n", conte_bombas(m, n, tab, 1, 1));
    return 0;
}

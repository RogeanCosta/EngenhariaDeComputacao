def prog_arit(num_ter, ter_ini, razao):
    for i in range(num_ter-1):
        print(ter_ini, end=', ')
        ter_ini = ter_ini + razao
    print(ter_ini)


def prog_geom(num_ter, ter_ini, razao):
    for i in range(num_ter-1):
        print(ter_ini, end=', ')
        ter_ini = ter_ini * razao
    print(ter_ini)


def quad_perf(n):
    for i in range(1, n):
        print(i*i, end=', ')
    print(n*n)


def fatorial(n):
    res = 1
    while n > 1:
        res *= n
        n -= 1
    return res

for i in range(31):
    print(i, "! = ", fatorial(i), sep='')


def mostre_divisores(n):
    for i in range(1, n//2+1):
        if n%i == 0:
            print(i, end=', ')
    print(n)

def conte_divisores(n):
    res = 1
    for i in range(1, n//2+1):
        if n%i == 0:
            res = res + 1
    return res

def é_primo(n):
    if n == 1: return False
    for i in range(2, n//2+1):
        if n%i == 0:
            return False
    return True

def mostre_primos(ini, fim):
    for i in range(ini, fim+1):
        if é_primo3(i):
            print(i, end=' ')


import turtle as tat
import time

pat = tat.Turtle()
pat.penup()
pat.backward(200)
pat.pendown()

def quadrado_cor(quem, tam_lado, esp=1, corL="black", corP="white"):
    quem.color(corL, corP)
    quem.pensize(esp)
    quem.begin_fill()
    for i in range(4):
        quem.forward(tam_lado)
        quem.left(90)
    quem.end_fill()

def gira_qs():
    ang = 2
    tam = 100
    for i in range(1,1441):
        quadrado_cor(tat, 200, 3, "blue", "yellow")
        quadrado_cor(pat, tam, 3, "brown", "orange")
        tat.update()
        time.sleep(0.05)
        tat.clear()
        pat.clear()
        tat.left(2)
        pat.left(ang)
        if i%180 == 0:
            ang = -ang
            tam = tam + 10
    quadrado_cor(tat, 200, 3, "blue", "yellow")
    quadrado_cor(pat, 100, 3, "brown", "orange")
    tat.update()

tat.tracer(0,0)
tat.hideturtle()
pat.hideturtle()
while True:
    gira_qs()

















## Procedimentos Recursivos

## SEQUÊNCIAS RECURSIVAS

    ## Defina uma função que retorne o enésimo termo
    ## da sequência 1, 2, 4, 8, 16, 32, 64, ...

        ## Versão algébrica
def seq_alg(n):
    return 2**(n-1)

        ## Versões iterativas (for e while)

def seq_ite_for(n):
    res = 1
    for i in range(n-1):
        res *= 2
    return res

def seq_ite_whi(n):
    res = 1
    while n > 1:
        res *= 2
        n -= 1
    return res

##for i in range(1, 11):
##    print(seq_alg(i), end= ' ')
##print("")
##    
##for i in range(1, 11):
##    print(seq_ite_for(i), end= ' ')
##print("")
##    
##for i in range(1, 11):
##    print(seq_ite_whi(i), end= ' ')
##print("")
    
        ## Versão recursiva

def seq_rec(n):
    if n == 1: return 1
    return 2 * seq_rec(n-1)

##for i in range(1, 11):
##    print(seq_rec(i), end= ' ')
##print("")

    ## Defina um procedimento que retorne o enésimo termo
    ## da sequência 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, ...

        ## Versão algébrica

import math
def fibo_alg(n):
    a = (1 + math.sqrt(5)) / 2
    b = (1 - math.sqrt(5)) / 2
    return int((a**n - b**n) / math.sqrt(5))

        ## Versões iterativas (for e while)

def fibo_ite_for(n):
    p = 1
    s = 1
    for i in range(n-2):
        p, s = s, p+s
    return s

def fibo_ite_whi(n):
    p = 1
    s = 1
    while n > 2:
        p, s = s, p+s
        n -= 1
    return s

        ## Versão recursiva

def fibo_rec(n):
    if n == 1 or n == 2: return 1
    return fibo_rec(n-2) + fibo_rec(n-1)


##for i in range(1, 11):
##    print(fibo_alg(i), end=' ')
##print("")
##
##for i in range(1, 11):
##    print(fibo_ite_for(i), end=' ')
##print("")
##
##for i in range(1, 11):
##    print(fibo_ite_whi(i), end=' ')
##print("")
##
##for i in range(1, 11):
##    print(fibo_rec(i), end=' ')
##print("")

##print(fibo_alg(40))
##print(fibo_ite_for(40))
##print(fibo_ite_whi(40))
##print(fibo_rec(40))

    ## Defina um procedimento que mostre os termos de uma
    ## PA (progressão aritmética) dados como parâmetros de
    ## entrada o número de termos (nt), o termo inicial (ti)
    ## e a razão (ra).

        ## Versão algébrica

def termo_pa_alg(n, ti, ra):
    return ti + (n-1)*ra

        ## Versões iterativas (for e while)

def termo_pa_ite_for(n, ti, ra):
    for i in range(n-1):
        ti += ra
    return ti

def termo_pa_ite_whi(n, ti, ra):
    while n > 1:
        ti += ra
        n -= 1
    return ti

        ## Versão recursiva

def termo_pa_rec(n, ti, ra):
    if n == 1: return ti
    return termo_pa_rec(n-1, ti+ra, ra)



## FUNÇÕES RECURSIVAS

    ## Defina uma função que retorna o fatorial de um número
    ## dado como parâmetro de entrada

        ## Versões iterativas (for e while)


        ## Versão recursiva

def fat_ite_for(n):
    res = 1
    for i in range(2, n+1):
        res *= i
    return res

def fat_ite_whi(n):
    res = 1
    while n > 1:
        res *= n
        n -= 1
    return res

def fat_rec(n):
    if n == 0: return 1
    return n * fat_rec(n-1)

##for i in range(11):
##    print(i, "! = ", fat_ite_for(i), sep='')
##print("------------------------------------")
##
##for i in range(11):
##    print(i, "! = ", fat_ite_whi(i), sep='')
##print("------------------------------------")
##
##for i in range(11):
##    print(i, "! = ", fat_rec(i), sep='')
##print("------------------------------------")


    ## Defina uma função que retorna o MDC de a e b

        ## Versão iterativa (while)

def mdc2(a, b):
    while a != b:
        if a > b:
            a -= b
        else:
            b -= a
    return a

def mdc(a, b):
    while b != 0:
        a, b = b, a%b
    return a
        ## Versão recursiva

def mdc_rec(a, b):
    if b == 0: return a
    return mdc_rec(b, a%b)


def mdc_rec2(a, b):
    if a == b: return a
    if a > b: return mdc_rec(a-b, b)
    return mdc_rec(a, b-a)

print(mdc(45,345))
print(mdc_rec(45,345))





## FIGURAS RECURSIVAS

    ## Defina um procedimento que desenha uma espiral quadrada
    ## dados como parâmetros de entrada o número de segmentos (ns),
    ## o tamanho inicial do segmento (ts) e o incremento (inc)

        ## Versões iterativas (for e while)
        ## Versão recursiva

    ## Defina um procedimento que desenha a curva de Koch dados
    ## como parâmetro de entrada o seu tamanho (tam) e o nível ou
    ## geração (ger)

        ## Versão recursiva





## Exercícios de Programação

## 1. Defina um procedimento que mostre os termos de uma
##    P.A. (progressão aritmética) tendo como parâmetros de
##    entrada:
##       num_ter - número de termos
##       ter_ini - termo inicial
##       razão - razão
## ---------------------------------------------
##    Exemplo:
##       Entrada:
##          num_ter = 10
##          ter_ini = 2
##          razão = 3
##       Saída:
##          2, 5, 8, 11, 14, 17, 20, 23, 26, 29

def prog_arit(num_ter, ter_ini, razao):
    for i in range(num_ter-1):
        print(ter_ini, end=', ')
        ter_ini = ter_ini + razao
    print(ter_ini)

#prog_arit(10, 2, 3)


## 2. Defina um procedimento que mostre os termos de uma
##    P.G. (progressão geométrica) tendo como parâmetros de
##    entrada:
##       num_ter - número de termos
##       ter_ini - termo inicial
##       razão - razão
## ---------------------------------------------
##    Exemplo:
##       Entrada:
##          num_ter = 10
##          ter_ini = 2
##          razão = 3
##       Saída:
##          2, 6, 18, 54, 162, 486, 1458, 4374, 13122, 39366

def prog_geom(num_ter, ter_ini, razao):
    for i in range(num_ter-1):
        print(ter_ini, end=', ')
        ter_ini = ter_ini * razao
    print(ter_ini)



## 3. Defina um procedimento que mostre os n primeiros
##    quadrados perfeitos dado n como parâmetro de entrada
## ---------------------------------------------
##    Exemplo:
##       Entrada:
##          n = 10
##       Saída:
##          1, 4, 9, 16, 25, 36, 49, 64, 81, 100

def quad_perf(n):
    raz_ini = 3
    ter_ini = 1
    for i in range(n-1):
        print(ter_ini, end=', ')
        ter_ini += raz_ini
        raz_ini += 2
    print(ter_ini)

def quad_perf2(n):
    x = 1
    for i in range(n-1):
        print(x**2, end=', ')
        x += 1
    print(x**2)

def quad_perf3(n):
    for i in range(1, n):
        print(i**2, end=', ')
    print(n**2)

#quad_perf3(12)









## 4. Defina um procedimento que receba como parâmetros a e b
##    e retorne a multiplicado por b
## ---------------------------------------------
##    Exemplo:
##       Entrada:
##          a = 3
##          b = 4
##       Retorno:
##          12

def multiplica(a, b):
    res = 0
    for i in range(a):
        res = res + b
    print(res)

x = multiplica(4,5)
print(x)

def prog_geom2(num_ter, ter_ini, razao):
    for i in range(num_ter-1):
        print(ter_ini, end=', ')
        ter_ini = multiplica(ter_ini, razao)
    print(ter_ini)

#prog_geom2(10,2,3)









## 5. Defina um procedimento que receba como parâmetros a e n
##    e retorne a elevado a n
## ---------------------------------------------
##    Exemplo:
##       Entrada:
##          a = 2
##          n = 10
##       Retorno:
##          1024

def expo(a,n):
    res = 1
    for i in range(n):
        res = res * a
    return res
    
print(expo(2,10))














## 6. Defina um procedimento que receba como parâmetro n
##    e retorne o fatorial de n
## ---------------------------------------------
##    Exemplo:
##       Entrada:
##          n = 5
##       Retorno:
##          120

## 7. Defina um procedimento que mostre os n primeiros termos
##    da sequência de Fibonacci tendo como parâmetros de
##    entrada:
##       num_ter - número de termos
##       pri_ter - primeiro termo (opcional = 0)
##       seg_ter = segundo termo (opcional = 1)
## ---------------------------------------------
##    Exemplo:
##       Entrada:
##          num_ter = 10
##          pri_ter = 0
##          seg_ter = 1
##       Saída:
##          0, 1, 2, 3, 5, 8, 13, 21, 34, 55








#include <stdio.h>
#include <stdlib.h>

void troca(int *a, int *b)
{
    int aux = *a;
    *a = *b;
    *b = aux;
}

int dobra(int a)
{
   return 2 * a;
}

void dobra2(int *a)
{
    *a = 2 * *a;
}

int main()
{
    int x = 10, y = 20;
    printf("Antes da troca:  x = %d,  y = %d\n", x, y);
    troca(&x, &y);
    printf("Depois da troca: x = %d,  y = %d\n", x, y);

    printf("\nO dobro de %d %c %d\n", x, 130, dobra(x));

    printf("\nO dobro de %d %c ", x, 130);
    dobra2(&x);
    printf("%d\n", x);

    return 0;
}

#include <stdio.h>
#include <stdlib.h>

void prog_arit(int num_ter, float ter_ini, float razao)
{
    int i;
    for(i=0; i<num_ter-1; i++)
    {
        printf("%.2f, ", ter_ini);
        ter_ini = ter_ini + razao;
    }
    printf("%.2f\n", ter_ini);
}

void quad_perf(int n)
{
    int i;
    for(i=1; i<n; i++)
        printf("%d, ", i*i);
    printf("%d\n", n*n);
}

unsigned long long fatorial(int n)
{
    unsigned long long res = 1;
    while(n > 1)
    {
        res *= n;
        n--;
    }
    return res;
}

int main()
{
    int i;
    //prog_arit(10, 2.2, 3.3);
    //quad_perf(10);
    for(i=0; i<=30; i++)
        printf("%d! = %I64u\n", i, fatorial(i));
    return 0;
}

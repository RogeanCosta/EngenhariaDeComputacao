import random
import data
import aluno

def gere_nome():
    nomes = ('Aline', 'Ana', 'Beatriz', 'Bernardo', 'Bruno', 'Camila', 'Carlos', 'Cecília',
             'Davi', 'Eduardo', 'Felipe', 'Francisco', 'Gabriel', 'Gérson', 'Heitor', 'Henrique',
             'Ingrid', 'Isabela', 'Júlia', 'Larissa', 'Laura', 'Leonardo', 'Lorena', 'Marcelo',
             'Márcia', 'Marcos', 'Mariana', 'Milena', 'Patrícia', 'Pedro', 'Priscila', 'Renato',
             'Ricardo', 'Rodrigo', 'Ronaldo', 'Samuel', 'Sérgio', 'Sofia', 'Tiago', 'Vinícius')
    sobrenomes = ('Abreu', 'Albuquerque', 'Almeida', 'Alencar', 'Alves', 'Amaral', 'Amorim',
                  'Andrade', 'Antunes', 'Arantes', 'Araújo', 'Arruda', 'Azevedo', 'Barros',
                  'Bastos', 'Batista', 'Bezerra', 'Brandão', 'Brito', 'Cabral', 'Campos',
                  'Cardoso', 'Carneiro', 'Carvalho', 'Castro', 'Cavalcante', 'Chagas', 'Chaves',
                  'Correia', 'Costa', 'Cruz', 'Dantas', 'Diniz', 'Duarte', 'Esteves', 'Fagundes',
                  'Fernandes', 'Ferraz', 'Ferreira', 'Figueiredo', 'Fonseca', 'Franco', 'Freire',
                  'Freitas', 'Furtado', 'Gomes', 'Gonçalves', 'Guedes', 'Guerra', 'Guimarães',
                  'Liberato', 'Marinho', 'Marques', 'Martins', 'Medeiros', 'Melo', 'Menezes',
                  'Monteiro', 'Montenegro', 'Moraes', 'Moreira', 'Moura', 'Nogueira', 'Noronha',
                  'Novaes', 'Oliveira', 'Pereira', 'Pinto', 'Resende', 'Ribeiro', 'Rios',
                  'Sampaio', 'Santana', 'Santos', 'Torres', 'Trindade', 'Vasconcelos', 'Vargas')
    res = random.choice(nomes) + " "
    sn1 = random.randint(0, len(sobrenomes)-1)
    sn2 = random.randint(0, len(sobrenomes)-1)
    while sn1 == sn2:
        sn2 = random.randint(0, len(sobrenomes)-1)
    return res + sobrenomes[sn1] + " " + sobrenomes[sn2]

def gere_data():
    return data.Data(random.randint(1,28), random.randint(1,12), random.randint(1980, 2000))

def gere_aluno(cod):
    return aluno.Aluno(cod, gere_nome(), gere_data(),
                       random.randint(50,100)/10, random.randint(50,100)/10)


##d1 = gere_data()
##print(d1)
##d2 = d1
##print(d2)
##d2.set_data(1,1,1900)
##print(d2)
##print(d1)
##
##alu = gere_aluno(1)
##print(alu)
##d, m, a = map(int, input("Digite nova data de nascimento (dd/mm/aaaa): ").split(sep='/'))
##alu.get_nasc().set_data(d,m,a)
##print(alu)













import time
import pickle
import aniversario
import celular
import contato
import massa_teste

def menu_principal():
    print("\n"+66*"=")
    print("Agenda de Contatos".center(66))
    print(66*"="+"\n")
    print("  1 - Buscar contato")
    print("  2 - Inserir contato")
    print("  3 - Excluir contato")
    print("  4 - Alterar")
    print("  5 - Mostrar contatos")
    print("  ----------------------")
    print("  0 - Sair do Aplicativo\n")
    return input("  Escolha uma opção: ")


def submenu_alterar():
    print("\n"+66*"=")
    print("Alteração de dados do contato".center(66))
    print(66*"="+"\n")
    print("  1 - Alterar nome")
    print("  2 - Alterar celular")
    print("  3 - Alterar aniversário")
    print("  ----------------------------")
    print("  0 - Voltar ao menu principal\n")
    return input("  Escolha uma opção: ")

def submenu_mostrar():
    print("\n"+66*"=")
    print("Mostrar contatos".center(66))
    print(66*"="+"\n")
    print("  1 - Ordenados pelo nome")
    print("  2 - Ordenados pelo aniversário")
    print("  ----------------------------")
    print("  0 - Voltar ao menu principal\n")
    return input("  Escolha uma opção: ")

def buscar_pelo_nome(lis):
    ini = input("  Digite as iniciais do nome: ")
    nc = 1
    for con in lis:
        if con.get_nome().startswith(ini):
            print("  {:2d} {:s}".format(nc, str(con)))
        nc += 1

def busca_binaria(lis, nome):
    ini = 0
    fim = len(lis)-1
    while ini <= fim:
        mei = (ini + fim) // 2
        if lis[mei].get_nome() == nome:
            return mei
        elif lis[mei].get_nome() < nome:
            ini = mei + 1
        else:
            fim = mei - 1
    return -1

def inserir_contato(lis):
    nom = input("  Nome: ")
    while busca_binaria(lis, nom) >= 0:
        print("  {:s} já cadastrado".format(nom))
        nom = input("  Redigite o nome: ")
    ddd = input("  DDD (xx): ")
    cel = input("  Telefone: ")
    while not celular.e_valido(ddd, cel):
        print(  "Número inválido, favor redigitar")
        ddd = input("  DDD (xx): ")
        cel = input("  Telefone: ")        
    dia, mes = map(int, input("  Aniversário (dd/mm): ").split(sep='/'))
    while not aniversario.e_valida(dia, mes):
        print("  Data inválida, favor redigitar")
        dia, mes = map(int, input("  Aniversário (dd/mm): ").split(sep='/'))
    lis.append(contato.Contato(nom,
                               celular.Celular(ddd, cel),
                               aniversario.Aniversario(dia,mes)))

def excluir_contato(lis):
    nc = int(input("  Número do contato: "))
    lis.pop(nc-1)

def principal():
    arq = open("contatos.arq", "rb")
    lis_con = pickle.load(arq)
    arq.close()
    while True:
        op = menu_principal()
        if op == '0':
            arq = open("contatos.arq", "wb")
            pickle.dump(lis_con, arq)
            arq.close()
            print("\n  ** Fim do aplicativo **")
            time.sleep(3)
            break
        elif op == '1':
            print(66*"-")
            print("{:s}".format("Buscar contato pelo nome".center(66)))
            print(66*"-")
            buscar_pelo_nome(lis_con)
        elif op == '2':
            print(66*"-")
            print("{:s}".format("Inserir contato".center(66)))
            print(66*"-")
            inserir_contato(lis_con)
            lis_con.sort()
        elif op == '3':
            print(66*"-")
            print("{:s}".format("Excluir contato".center(66)))
            print(66*"-")
            excluir_contato(lis_con)
        elif op == '4':
            while True:
                op2 = submenu_alterar()
                if op2 == '0':
                    break
                elif op2 == '1':
                    print(66*"-")
                    print("{:s}".format("Alterar nome".center(66)))
                    print(66*"-")
                    nc = int(input("  Número do contato: "))
                    print("  Nome atual: {:s}".format(lis_con[nc-1].get_nome()))
                    nn = input("  Novo nome: ")
                    lis_con[nc-1].set_nome(nn)
                elif op2 == '2':
                    print(66*"-")
                    print("{:s}".format("Alterar telefone".center(66)))
                    print(66*"-")
                    nc = int(input("  Número do contato: "))
                    print("  Número atual: {:s}".format(str(lis_con[nc-1].get_cel())))
                    ddd = input("  Novo DDD: ")
                    num = input("  Novo número (só números): ")
                    lis_con[nc-1].set_celular(ddd, num)                    
                    
                elif op2 == '3':
                    print(66*"-")
                    print("{:s}".format("Alterar aniversário".center(66)))
                    print(66*"-")
                    nc = int(input("  Número do contato: "))
                    print("  Aniversário atual: {:s}".format(str(lis_con[nc-1].get_ani())))
                    dia, mes = map(int, input("  Novo aniversário (dd/mm): ").split(sep='/'))
                    lis_con[nc-1].set_aniversario(dia, mes)
                else:
                    print("\n  * ENTRADA INVÁLIDA *\n")
        elif op == '5':
            while True:
                op2 = submenu_mostrar()
                if op2 == '0':
                    break
                elif op2 == '1':
                    print(66*"-")
                    print("{:s}".format("Contatos ordenados pelo nome".center(66)))
                    print(66*"-")
                    nc = 1
                    for con in lis_con:
                        print("{:2d} {:s}".format(nc, str(con)))
                        nc += 1
                elif op2 == '2':
                    print(66*"-")
                    print("{:s}".format("Contatos ordenados pelo aniversário".center(66)))
                    print(66*"-")
                    for con in sorted(lis_con, key=lambda con : con.get_ani()):
                        print(con)
                else:
                    print("\n  * ENTRADA INVÁLIDA *\n")
        else:
            print("\n  * ENTRADA INVÁLIDA *\n")

principal()

import turtle

def quadrado(tamLado, esp=1, cor="black", corp = "white"):
    ''' Desenha um quadrado dado o tamanho do lado - tamLado
    Parâmetros opcionais:
    esp - espessura do lápis
    cor - cor do lápis
    corp - cor de pintura
    '''
    turtle.pensize (esp)
    turtle.pencolor (cor)
    turtle.fillcolor (corp)
    turtle.begin_fill ()
    for i in range(4):
        turtle.forward(tamLado)
        turtle.left (90)
    turtle.end_fill ()

def retângulo(base, altura, esp=1, cor="black", corp = "white"):
    turtle.pensize (esp)
    turtle.pencolor (cor)
    turtle.fillcolor (corp)
    turtle.begin_fill ()
    for i in range(2):
        turtle.forward(base)
        turtle.left (90)
        turtle.forward(altura)
        turtle.left (90)
    turtle.end_fill ()

def triânguloEq(tamLado, esp=1, cor="black", corp = "white"):
    turtle.color (cor,corp)
    turtle.pensize (esp)
    turtle.begin_fill ()
    for i in range(3):
        turtle.forward(tamLado)
        turtle.left (120)
    turtle.end_fill ()

def polígonoRegular(numLados, tamLado, esp=1, cor="black", corp = "white"):
    turtle.pensize (esp)
    turtle.pencolor (cor)
    turtle.fillcolor (corp)
    turtle.begin_fill ()
    for i in range(numLados):
        turtle.forward (tamLado)
        turtle.left (360 / numLados)
    turtle.end_fill ()

def espiralQuad(numSeg,tamIni,inc):
    for i in range(numSeg):
        turtle.forward (tamIni)
        turtle.right (90)
        tamIni = tamIni + inc

def espiral(numSeg,tamIni,inc,ang):
    for i in range(numSeg):
        turtle.forward (tamIni)
        turtle.right (ang)
        tamIni = tamIni + inc

def inspiral(numSeg,tam,inc,angIni):
    for i in range(numSeg):
        turtle.forward (tam)
        turtle.right (angIni)
        angIni = angIni + inc











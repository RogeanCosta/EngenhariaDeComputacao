class Aluno:
    def __init__(self, cod, nome, nasc, ap1, ap2):
        self.__codigo = cod
        self.__nome = nome
        self.__nasc = nasc
        self.__ap1 = ap1
        self.__ap2 = ap2

    def get_codigo(self):
        return self.__codigo

    def get_nome(self):
        return self.__nome

    def get_nasc(self):
        return self.__nasc

    def get_ap1(self):
        return self.__ap1

    def get_ap2(self):
        return self.__ap2

    def media(self):
        ap1 = 0 if self.__ap1 > 10.5 else self.__ap1
        ap2 = 0 if self.__ap2 > 10.5 else self.__ap2
        return (2 * ap1 + 3 * ap2) / 5

    def __str__(self):
        res = "{:06d} {:30s} {:s} ".format(
            self.__codigo, self.__nome, str(self.__nasc))
        if self.__ap1 > 10.5:
            res = res + '      '
        else:
            res = res + "{:5.1f} ".format(self.__ap1)
        if self.__ap2 > 10.5:
            res = res + '      '
        else:
            res = res + "{:5.1f} ".format(self.__ap2)
        return res + "{:5.1f}".format(self.media())

    def __lt__(self, outro):    
        return self.__codigo < outro.__codigo

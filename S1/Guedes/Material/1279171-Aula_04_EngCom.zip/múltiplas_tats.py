import turtle
import random
import time

turtle.shape("turtle")
turtle.color("green")

ana = turtle.Turtle("turtle")    # Construtor
ana.color("red")

rui = turtle.Turtle("turtle")
rui.color("blue")

def passo(quem, dist, ang):
    quem.forward(dist)
    quem.left(random.randint(-ang, ang))


turtle.tracer(0,0)
for i in range(15000):
    alt = turtle.window_height()
    lar = turtle.window_width()
    passo(ana, 5, 25)
    if abs(ana.xcor()) > lar/2:
        ana.penup()
        ana.goto(-ana.xcor(), ana.ycor())
        ana.pendown()
    if abs(ana.ycor()) > alt/2:
        ana.penup()
        ana.goto(ana.xcor(), -ana.ycor())
        ana.pendown()
    passo(rui, 3, 35)
    rui.setheading(rui.towards(ana.position()))
##    if abs(rui.xcor()) > 300:
##        rui.setheading(rui.towards(0,0))
##    if abs(rui.ycor()) > 200:
##        rui.setheading(rui.towards(0,0))
    passo(turtle, 4, 15)
    if abs(turtle.xcor()) > lar/2:
        turtle.setheading(turtle.towards(0,0))
    if abs(turtle.ycor()) > alt/2:
        turtle.setheading(turtle.towards(0,0))
    turtle.update()
    time.sleep(0.001)














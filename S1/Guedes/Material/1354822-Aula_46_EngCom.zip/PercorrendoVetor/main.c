#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void preenche_vetor(int ne, int vet[ne])
{
    int i;
    for(i=0; i<ne; i++)
        vet[i] = rand()%100;
}

void mostre_vetor(int ne, int *vet)
{
    int i;
    for(i=0; i<ne-1; i++)
        printf("%d, ", vet[i]);
    printf("%d\n", vet[i]);
}

void mostre_vetor2(int ne, int *vet)
{
    int i;
    for(i=0; i<ne-1; i++) {
        printf("%d, ", *vet);
        vet++;
    }
    printf("%d\n", *vet);
}



int main()
{
    srand(time(NULL));
    int vetor[50];
    int ne = 15;
    preenche_vetor(ne, vetor);
    mostre_vetor(ne, vetor);
    mostre_vetor2(ne, vetor);
    return 0;
}

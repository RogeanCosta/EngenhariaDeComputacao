#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

char lin_dup[67] = "==================================================================\n";
char lin_sim[67] = "------------------------------------------------------------------\n";

void printc(char *s, int tam)
{
    int ne = (tam - strlen(s)) / 2;
    while(ne > 0)
    {
        printf(" ");
        ne--;
    }
    printf(s);
}

void sleep(time_t delay)
{
    time_t timer0, timer1;
    time(&timer0);
    do
    {
        time(&timer1);
    } while((timer1 - timer0) < delay);
}

int menu_principal()
{
    printf("\n%s", lin_dup);
    printc("T\xa1tulo do Menu Principal", 66);
    printf("\n%s\n", lin_dup);
    printf("  1 - Op%c%co 1 (submenu)\n", 135, 198);
    printf("  2 - Op%c%co 2\n", 135, 198);
    printf("  3 - Op%c%co 3\n", 135, 198);
    printf("  4 - Op%c%co 4\n", 135, 198);
    printf("  ----------------------\n");
    printf("  0 - Sair do Aplicativo\n");
    printf("\n  Escolha uma op%c%co: ", 135, 198);
    fflush(stdin);
    return getchar();
}

int submenu()
{
    printf("\n%s", lin_dup);
    printc("T\xa1tulo do Submenu", 66);
    printf("\n%s\n", lin_dup);
    printf("  1 - Op%c%co 1\n", 135, 198);
    printf("  2 - Op%c%co 2\n", 135, 198);
    printf("  3 - Op%c%co 3\n", 135, 198);
    printf("  4 - Op%c%co 4\n", 135, 198);
    printf("  ----------------------------\n");
    printf("  0 - Voltar ao menu principal\n");
    printf("\n  Escolha uma op%c%co: ", 135, 198);
    fflush(stdin);
    return getchar();
}

int main()
{
    char op, op2;
    while(1)
    {
        op = menu_principal();
        if (op == '0')
        {
            printf("\n  ** Fim do aplicativo **");
            sleep(3);
            break;
        }
        switch(op)
        {
            case '1':
                while(1)
                {
                    op2 = submenu();
                    if (op2 == '0')
                    {
                        break;
                    }
                    switch(op2)
                    {
                        case '1':
                            printf("\n%s", lin_sim);
                            printc("Op\x87\xc6o 1 do Submenu",66);
                            printf("\n%s\n", lin_sim);
                            break;
                        case '2':
                            printf("\n%s", lin_sim);
                            printc("Op\x87\xc6o 2 do Submenu",66);
                            printf("\n%s\n", lin_sim);
                            break;
                        case '3':
                            printf("\n%s", lin_sim);
                            printc("Op\x87\xc6o 3 do Submenu",66);
                            printf("\n%s\n", lin_sim);
                            break;
                        case '4':
                            printf("\n%s", lin_sim);
                            printc("Op\x87\xc6o 4 do Submenu",66);
                            printf("\n%s\n", lin_sim);
                            break;
                        default:
                            printf("\n\n  Op%c%co inv%clida\n\n",135,198,160);
                    }
                }
                break;
            case '2':
                printf("\n%s", lin_sim);
                printc("T\xa1tulo da Op\x87\xc6o 2", 66);
                printf("\n%s\n", lin_sim);
                break;
            case '3':
                printf("\n%s", lin_sim);
                printc("T\xa1tulo da Op\x87\xc6o 3", 66);
                printf("\n%s\n", lin_sim);
                break;
            case '4':
                printf("\n%s", lin_sim);
                printc("T\xa1tulo da Op\x87\xc6o 4", 66);
                printf("\n%s\n", lin_sim);
                break;
            default:
                printf("\n\n  Op%c%co inv%clida\n\n",135,198,160);
        }
    }
    return 0;
}

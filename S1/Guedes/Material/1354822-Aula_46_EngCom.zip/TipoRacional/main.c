#include <stdio.h>
#include <stdlib.h>
#include "racional.h"

int main()
{
    TRacional ra;
    ra.p = 2;
    ra.q = -1;
    mostre_racional(ra);
    return 0;
}

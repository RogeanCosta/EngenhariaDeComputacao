import matematica
import time

while True:
    try:
        print("***********************")
        print("* Cálculo do Fatorial *")
        print("***********************")

        entrada = input("  Digite um inteiro >= 0 (negativo para sair): ")
        num = int(entrada)

        if num < 0:
            print("\n  FIM  DO APLICATIVO\n\n")
            time.sleep(3)
            break

        print("\n  ", num, "! = ", sep='', end='')
        if num > 1 and num <= 10:
            for i in range(num, 1, -1):
                print(i, " x ", sep='', end='')
            print("1 = ", end='')
        print(matematica.sep_milhares(matematica.fatorial(num)))
        print("\n")
    except ValueError:
        print("\n  *** Favor digitar um número inteiro ***\n\n")


        

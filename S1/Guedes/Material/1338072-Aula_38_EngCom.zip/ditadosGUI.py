import tkinter as tk
from tkinter import messagebox
import random
import pickle


##lis_dit = ["Água mole em pedra dura, tanto bate até que fura",
##           "Em casa de ferreiro, espeto de pau",
##           "Quem tem boca, vai a Roma"]
arq = open("ditados.arq", "rb")
lis_dit = pickle.load(arq)
arq.close()
atual = 0
novo = 1

jan = tk.Tk()

dit_var = tk.StringVar(jan)
dit_var.set(lis_dit[0])
ent_dit = tk.Entry(jan, width=60, textvariable=dit_var, state='readonly')
ent_dit.configure(font=("Arial", "18"), justify=tk.CENTER)
ent_dit.grid(column=0, row=0, columnspan=5, padx=5, pady=5)

def pro_dit():
    global atual
    atual = (atual + 1) % len(lis_dit)
    dit_var.set(lis_dit[atual])

bot_pro = tk.Button(jan, text='Próximo', command=pro_dit)
bot_pro.configure(font=("Arial", "12", "bold"), padx=10)
bot_pro.grid(column=0, row=1, pady=5)

def dit_ant():
    global atual
    atual -= 1
    if atual < 0:
        atual = len(lis_dit) - 1
    dit_var.set(lis_dit[atual])

bot_ant = tk.Button(jan, text='Anterior', command=dit_ant)
bot_ant.configure(font=("Arial", "12", "bold"), padx=10)
bot_ant.grid(column=1, row=1, pady=5)

def dit_ale():
    global atual
    atual = random.randint(0, len(lis_dit)-1)
    dit_var.set(lis_dit[atual])

bot_ale = tk.Button(jan, text='Aleatório', command=dit_ale)
bot_ale.configure(font=("Arial", "12", "bold"), padx=10)
bot_ale.grid(column=2, row=1, pady=5)

def nov_dit():
    global novo, atual
    if novo == 1:
        messagebox.showinfo('Novo ditado',
                            'Digite o novo ditado e clique em novo mais uma vez')
        bot_pro.configure(state=tk.DISABLED)
        bot_ant.configure(state=tk.DISABLED)
        bot_ale.configure(state=tk.DISABLED)
        bot_exc.configure(state=tk.DISABLED)
        dit_var.set("")
        ent_dit.configure(state=tk.NORMAL)
        ent_dit.focus()
        novo = 2
    else:
        lis_dit.append(dit_var.get())
        bot_pro.configure(state=tk.NORMAL)
        bot_ant.configure(state=tk.NORMAL)
        bot_ale.configure(state=tk.NORMAL)
        bot_exc.configure(state=tk.NORMAL)
        atual = len(lis_dit) - 1
        ent_dit.configure(state='readonly')
        novo = 1
        arq = open("ditados.arq", "wb")
        pickle.dump(lis_dit, arq)
        arq.close()

bot_nov = tk.Button(jan, text='Novo ditado', command=nov_dit)
bot_nov.configure(font=("Arial", "12", "bold"))
bot_nov.grid(column=3, row=1, pady=5)

def exc_dit():
    global atual
    res = messagebox.askyesno("Exclusão de ditado",
                        "Deseja excluir " + dit_var.get() + "?")
    if res:
        lis_dit.pop(atual)
        if len(lis_dit) > 0:
            atual -= 1
            if atual < 0:
                atual = len(lis_dit)-1
            dit_var.set(lis_dit[atual])
        else:
            bot_pro.configure(state=tk.DISABLED)
            bot_ant.configure(state=tk.DISABLED)
            bot_ale.configure(state=tk.DISABLED)
            bot_exc.configure(state=tk.DISABLED)
            dit_var.set("")
        arq = open("ditados.arq", "wb")
        pickle.dump(lis_dit, arq)
        arq.close()
        

bot_exc = tk.Button(jan, text='Excluir ditado', command=exc_dit)
bot_exc.configure(font=("Arial", "12", "bold"))
bot_exc.grid(column=4, row=1, pady=5)

jan.title("DITADOS POPULARES")
jan.resizable(0,0)
jan.mainloop()

import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
import matematica as mat

win = tk.Tk()
win.title("Divisores e Múltiplos")

rot1 = ttk.Label(win, text='A =', width=16, anchor=tk.E)
rot1.grid(column=0, row=0, pady=5)

entA = tk.StringVar()
ent_entA = ttk.Entry(win, width=4, textvariable=entA)
ent_entA.grid(column=1, row=0, pady=5)

rot2 = ttk.Label(win, text='          B =')
rot2.grid(column=2, row=0, pady=5)

entB = tk.StringVar()
ent_entB = ttk.Entry(win, width=4, textvariable=entB)
ent_entB.grid(column=3, row=0, pady=5)

rot3 = ttk.Label(win, text='          MDC(A, B) =')
rot3.grid(column=4, row=0, pady=5)

mdcAB = tk.StringVar()
ent_mdcAB = ttk.Entry(win, width=4, state=tk.DISABLED,  textvariable=mdcAB)
ent_mdcAB.grid(column=5, row=0, pady=5)

rot4 = ttk.Label(win, text='          MMC(A, B) =')
rot4.grid(column=6, row=0, pady=5)

mmcAB = tk.StringVar()
ent_mmcAB = ttk.Entry(win, width=4, state=tk.DISABLED, textvariable=mmcAB)
ent_mmcAB.grid(column=7, row=0, pady=5)


def mostrar():
    try:
        valA = int(entA.get())
        valB = int(entB.get())
        if valA > 0 and valB > 0:
            mdcAB.set(mat.mdc(valA, valB))
            mmcAB.set(mat.mmc(valA, valB))
            divA.set(mat.str_divisores(valA))
            divB.set(mat.str_divisores(valB))
        else:
            messagebox.showerror("Entrada Inválida", "Digite inteiros maiores que zero")
            entA.set("")
            entB.set("")
            ent_entA.focus()
    except:
        messagebox.showerror("Entrada Inválida", "Digite inteiros")

bot_mostrar = ttk.Button(win, text='Mostrar', command=mostrar)
bot_mostrar.grid(column=8, row=0, pady=5)

rot5 = ttk.Label(win, text='Divisores de A:')
rot5.grid(column=0, row=1, pady=5)

divA = tk.StringVar()
ent_divA = ttk.Entry(win, width=82, state=tk.DISABLED, textvariable=divA)
ent_divA.grid(column=1, row=1, columnspan=8, pady=5, padx=5)

rot6 = ttk.Label(win, text='Divisores de B:')
rot6.grid(column=0, row=2, pady=5)

divB = tk.StringVar()
ent_divB = ttk.Entry(win, width=82, state=tk.DISABLED, textvariable=divB)
ent_divB.grid(column=1, row=2, columnspan=8, pady=5, padx=5)

def apaga_saidaA(event):
    mdcAB.set("")
    mmcAB.set("")
    divA.set("")
ent_entA.bind("<Key>", apaga_saidaA)

def apaga_saidaB(event):
    mdcAB.set("")
    mmcAB.set("")
    divB.set("")
ent_entB.bind("<Key>", apaga_saidaB)

def bot_padrao(event):
    bot_mostrar.invoke()
win.bind("<Return>", bot_padrao)

win.mainloop()

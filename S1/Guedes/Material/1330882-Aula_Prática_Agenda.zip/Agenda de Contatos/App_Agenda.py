import time

def menu_principal():
    print("\n"+66*"=")
    print("Título do Menu Principal".center(66))
    print(66*"="+"\n")
    print("  1 - Opção 1")
    print("  2 - Opção 2")
    print("  3 - Opção 3")
    print("  4 - Opção 4")
    print("  ----------------------")
    print("  0 - Sair do Aplicativo\n")
    return input("  Escolha uma opção: ")


def submenu():
    print("\n"+66*"=")
    print("Título do Submenu".center(66))
    print(66*"="+"\n")
    print("  1 - Opção 1")
    print("  2 - Opção 2")
    print("  3 - Opção 3")
    print("  4 - Opção 4")
    print("  ----------------------------")
    print("  0 - Voltar ao menu principal\n")
    return input("  Escolha uma opção: ")

def principal():
    while True:
        op = menu_principal()
        if op == '0':
            print("\n  ** Fim do aplicativo **")
            time.sleep(3)
            break
        elif op == '1':
            while True:
                op2 = submenu()
                if op2 == '0':
                    break
                elif op2 == '1':
                    print(66*"-")
                    print("{:s}".format("Título do Submenu 1".center(66)))
                elif op2 == '2':
                    print(66*"-")
                    print("{:s}".format("Título do Submenu 2".center(66)))
                elif op2 == '3':
                    print(66*"-")
                    print("{:s}".format("Título do Submenu 3".center(66)))
                elif op2 == '4':
                    print(66*"-")
                    print("{:s}".format("Título do Submenu 4".center(66)))
                else:
                    print("\n  * ENTRADA INVÁLIDA *\n")
        elif op == '2':
            print(66*"-")
            print("{:s}".format("Título da Opção 2".center(66)))
            print(66*"-")
        elif op == '3':
            print(66*"-")
            print("{:s}".format("Título da Opção 3".center(66)))
            print(66*"-")
            buscar_pelo_nome(lis_alu)
        elif op == '4':
            print(66*"-")
            print("{:s}".format("Título da Opção 4".center(66)))
            print(66*"-")
        else:
            print("\n  * ENTRADA INVÁLIDA *\n")

principal()

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "matematica.h"

void sleep(time_t delay)
{
    time_t timer0, timer1;
    time(&timer0);
    do
    {
        time(&timer1);
    } while((timer1 - timer0) < delay);
}

int main()
{
    int num, i;

//    char snum[51];
//    unsigned long long n;
//    scanf("%I64u", &n);
//    div_milhar(n, snum);
//    puts(snum);
//    return 0;

//    for(i=0; i<256; i++)
//    {
//        printf("%c %03d %X\n", i, i, i);
//    }
//    return 0;
    while(1)
    {
        printf("***********************\n");
        printf("* C%clculo do Fatorial *\n", 160);
        printf("***********************\n");
        printf("  Digite um inteiro >= 0 (negativo para sair): ");
        scanf("%d", &num);
        if(num < 0)
        {
            printf("\n  *** Fim do aplicativo ***\n\n");
            sleep(3);
            break;
        }
        if(num > 20)
        {
            printf("\n  *** Valor fora da faixa [0, 20] ***\n\n");
            continue;
        }
        printf("\n  %d! = ", num);
        if(num > 1 && num <= 10) {
            for(i=num; i>1; i--)
                printf("%d x ", i);
            printf("1 = ");
        }
        printf("%I64u\n", fatorial(num));
        printf("\n");
    }

    return 0;
}

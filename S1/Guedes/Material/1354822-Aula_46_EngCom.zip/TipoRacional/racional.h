struct racional
{
    int p;
    int q;
};
typedef struct racional TRacional;

void mostre_racional(TRacional r)
{
    if(r.q < 0)
    {
        r.p = -r.p;
        r.q = -r.q;
    }
    if(r.q == 1)
        printf("%d", r.p);
    else
        printf("%d/%d", r.p, r.q);
}

TRacional soma_racional(TRacional ra, TRacional rb)
{
    TRacional res;

    return res;
}









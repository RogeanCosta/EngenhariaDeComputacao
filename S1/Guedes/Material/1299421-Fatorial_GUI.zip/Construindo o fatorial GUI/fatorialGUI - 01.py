"""Alterando o título da janela"""

import tkinter as tk

win = tk.Tk()
win.title("Fatorial - IFCE")    # <--

win.mainloop()

